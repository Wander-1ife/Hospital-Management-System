<?php
session_start();
require 'database.php';
require __DIR__ . '/Tcpdf/TCPDF-main/tcpdf.php';


if (!isset($_SESSION['user_id']) || $_SESSION['role'] !== 'Patient') {
    header("Location: login.php");
    exit();
}

$visit_id = filter_input(INPUT_GET, 'visit_id', FILTER_VALIDATE_INT);
if (!$visit_id) {
    die("Invalid visit ID");
}

$stmt = $pdo->prepare("SELECT Visits.date AS visit_date, Doctors.name AS doctor_name, Patients.name AS patient_name, 
                      Invoices.doctor_fee, Invoices.hospital_charges, Invoices.total 
                      FROM Visits 
                      JOIN Doctors ON Visits.doctor_id = Doctors.id 
                      JOIN Patients ON Visits.patient_id = Patients.id 
                      JOIN Invoices ON Visits.id = Invoices.visit_id 
                      WHERE Visits.id = :visit_id AND Visits.patient_id = :patient_id");
$stmt->execute(['visit_id' => $visit_id, 'patient_id' => $_SESSION['user_id']]);
$invoice = $stmt->fetch(PDO::FETCH_ASSOC);

if (!$invoice) {
    die("Invoice not found.");
}

$pdf = new TCPDF();
$pdf->AddPage();
$pdf->SetFont('Helvetica', '', 12);
$pdf->writeHTML("
    <h1>Invoice</h1>
    <p>Patient: {$invoice['patient_name']}</p>
    <p>Doctor: {$invoice['doctor_name']}</p>
    <p>Date: {$invoice['visit_date']}</p>
    <table border='1' cellpadding='5'>
        <tr><td>Doctor Fee</td><td>{$invoice['doctor_fee']}</td></tr>
        <tr><td>Hospital Charges</td><td>{$invoice['hospital_charges']}</td></tr>
        <tr><td><strong>Total</strong></td><td><strong>{$invoice['total']}</strong></td></tr>
    </table>
");
$pdf->Output();
?>
