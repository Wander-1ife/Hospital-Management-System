<?php
require_once 'database.php'; // Include database connection

// Initialize messages
$error = '';
$success = '';

// Handle Sign Up
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $username = $_POST['username'];
    $name = $_POST['name'];
    $password = $_POST['password'];
    
    // Set the role to 'Admin' directly
    $role = 'Admin';

    // Hash the password
    $password_hash = password_hash($password, PASSWORD_DEFAULT);

    // Insert admin data into the database
    $sql = "INSERT INTO admins (username, name, password_hash, role) 
            VALUES (:username, :name, :password_hash, :role)";
    try {
        $stmt = $pdo->prepare($sql);
        $stmt->execute([
            ':username' => $username,
            ':name' => $name,
            ':password_hash' => $password_hash,
            ':role' => $role
        ]);

        // Show success message
        $success = "Registration successful! You can now log in as an admin.";
    } catch (PDOException $e) {
        $error = "Error during registration: " . $e->getMessage();
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Sign Up | HealthHorizon</title>
    <link href="https://fonts.googleapis.com/css2?family=Roboto:wght@400;500;700&display=swap" rel="stylesheet">
    <style>
        body {
            font-family: 'Roboto', sans-serif;
            margin: 0;
            padding: 0;
            background-color: #f7f9fc;
            display: flex;
            justify-content: center;
            align-items: center;
            height: 100vh;
            color: #333;
        }
        .form-container {
            background: #ffffff;
            padding: 30px 40px;
            border-radius: 10px;
            box-shadow: 0px 8px 16px rgba(0, 0, 0, 0.2);
            width: 100%;
            max-width: 500px;
            text-align: center;
        }
        h2 {
            color: #0056b3;
            margin-bottom: 20px;
            font-size: 24px;
        }
        label {
            font-weight: 600;
            margin-top: 10px;
            display: block;
            text-align: left;
        }
        input, button {
            width: 100%;
            padding: 12px;
            margin: 10px 0;
            border: 1px solid #ddd;
            border-radius: 5px;
            font-size: 16px;
        }
        button {
            background-color: #0056b3;
            color: white;
            border: none;
            cursor: pointer;
            font-size: 18px;
            transition: background-color 0.3s ease;
        }
        button:hover {
            background-color: #00408a;
        }
        .back-button {
            margin-top: 15px;
            display: inline-block;
            background-color: #023e8a;
            color: white;
            text-decoration: none;
            padding: 10px 20px;
            border-radius: 5px;
            font-size: 16px;
            transition: background-color 0.3s ease;
        }
        .back-button:hover {
            background-color: #00b4d8;
        }
        .message {
            margin-top: 20px;
            font-size: 16px;
        }
        .success {
            color: green;
        }
        .error {
            color: red;
        }
    </style>
</head>
<body>
    <div class="form-container">
        <h2>Admin Sign Up | HealthHorizon</h2>
        <form method="POST" action="">
            <label for="username">Username</label>
            <input type="text" id="username" name="username" placeholder="Username" required>

            <label for="name">Full Name</label>
            <input type="text" id="name" name="name" placeholder="Full Name" required>

            <label for="password">Create Password</label>
            <input type="password" id="password" name="password" placeholder="Create Password" required>

            <button type="submit">Sign Up</button>
        </form>

        <!-- Display Messages -->
        <div class="message">
            <?php if (!empty($error)) echo "<p class='error'>$error</p>"; ?>
            <?php if (!empty($success)) echo "<p class='success'>$success</p>"; ?>
        </div>

        <!-- Back Button -->
        <a href="index.php" class="back-button">← Back to Main Page</a>
    </div>
</body>
</html>
