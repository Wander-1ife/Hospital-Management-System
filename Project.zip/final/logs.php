<?php
session_start();
require 'database.php';

// Check if the user is logged in as Admin
if (!isset($_SESSION['user_id']) || $_SESSION['role'] !== 'Admin') {
    header("Location: login.php");
    exit();
}

// Fetch login logs
try {
    $stmt = $pdo->query("
        SELECT 
            id, 
            user_id, 
            username, 
            status, 
            ip_address, 
            user_agent, 
            login_time 
        FROM login_logs
        ORDER BY login_time DESC
    ");
    $login_logs = $stmt->fetchAll(PDO::FETCH_ASSOC);
} catch (PDOException $e) {
    $error = "Error fetching logs: " . $e->getMessage();
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login Logs | HealthHorizon</title>
    <link href="https://fonts.googleapis.com/css2?family=Roboto:wght@400;500;700&display=swap" rel="stylesheet">
    <style>
        body {
            font-family: 'Roboto', sans-serif;
            margin: 0;
            padding: 0;
            background-color: #f8f9fa;
            color: #333;
            display: flex;
            flex-direction: column;
            min-height: 100vh;
        }
        header {
            background-color: #0056b3;
            color: white;
            padding: 20px;
        }
        header .header-content {
            display: flex;
            align-items: center;
        }
        header .logo-container {
            display: flex;
            align-items: center;
            justify-content: center;
            padding: 10px;
            border: 2px solid #ffffff;
            border-radius: 10px;
            background-color: white;
            box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
            margin-right: 15px;
        }
        header img {
            height: 50px;
            width: auto;
        }
        nav {
            background-color: white;
            box-shadow: 0px 4px 8px rgba(0, 0, 0, 0.1);
            display: flex;
            justify-content: center;
            align-items: center;
            gap: 20px;
            padding: 15px 0;
        }
        nav a {
            color: #0056b3;
            text-decoration: none;
            padding: 10px 20px;
            border: 2px solid #0056b3;
            border-radius: 25px;
            font-size: 16px;
            font-weight: bold;
            transition: all 0.3s ease;
        }
        nav a:hover, nav a.active {
            background-color: #0056b3;
            color: white;
        }
        .container {
            flex: 1;
            max-width: 960px;
            margin: 30px auto;
            background: white;
            padding: 30px;
            border-radius: 10px;
            box-shadow: 0px 8px 16px rgba(0, 0, 0, 0.2);
        }
        h2 {
            color: #0056b3;
            margin-bottom: 20px;
        }
        table {
            width: 100%;
            border-collapse: collapse;
            margin-top: 20px;
        }
        th, td {
            border: 1px solid #ddd;
            padding: 10px;
            text-align: left;
        }
        th {
            background-color: #0056b3;
            color: white;
        }
        .error {
            color: red;
            margin-bottom: 15px;
        }
        footer {
            background-color: #023e8a;
            color: white;
            text-align: center;
            padding: 10px 0;
            font-size: 14px;
            margin-top: auto;
        }
    </style>
</head>
<body>
<header>
    <div class="header-content">
        <div class="logo-container">
            <img src="/PIC/WhatsApp Image 2024-12-08 at 15.12.54_61cd6b5b.jpg" alt="HealthHorizon Logo">
        </div>
        <h1>Login Logs</h1>
    </div>
</header>
 <nav>
 <a href="admin_dashboard.php">Dashboard</a>
        <a href="manage_doctors.php">Manage Doctors</a>
        <a href="manage_patients.php">Manage Patients</a>
        <a href="manage_appointments.php">Manage Appointments</a>
        <a href="logs.php">Logs</a>
    </nav>

<div class="container">
    <h2>Login Logs</h2>
    <?php if (isset($error)): ?>
        <p class="error"><?= htmlspecialchars($error) ?></p>
    <?php elseif (empty($login_logs)): ?>
        <p>No login logs available.</p>
    <?php else: ?>
        <table>
            <thead>
                <tr>
                    <th>Log ID</th>
                    <th>User ID</th>
                    <th>Username</th>
                    <th>Status</th>
                    <th>IP Address</th>
                    <th>Role</th>
                    <th>Login Time</th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($login_logs as $log): ?>
                    <tr>
                        <td><?= htmlspecialchars($log['id']) ?></td>
                        <td><?= htmlspecialchars($log['user_id']) ?></td>
                        <td><?= htmlspecialchars($log['username']) ?></td>
                        <td><?= htmlspecialchars($log['status']) ?></td>
                        <td><?= htmlspecialchars($log['ip_address'] ?? 'N/A') ?></td>
                        <td><?= htmlspecialchars($log['user_agent'] ?? 'N/A') ?></td>
                        <td><?= htmlspecialchars($log['login_time']) ?></td>
                    </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
    <?php endif; ?>
</div>
<footer>
    &copy; 2024 HealthHorizon. All Rights Reserved.
</footer>
</body>
</html>
