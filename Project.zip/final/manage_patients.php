<?php
session_start();
require 'database.php';

// Redirect if not admin
if (!isset($_SESSION['user_id']) || $_SESSION['role'] !== 'Admin') {
    header("Location: login.php");
    exit();
}

// Handle Add Patient Form Submission
$message = '';
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['add_patient'])) {
    $name = $_POST['name'];
    $dob = $_POST['dob'];
    $gender = $_POST['gender'];
    $address = $_POST['address'];
    $contact = $_POST['contact'];
    $emergency_contact = $_POST['emergency_contact'];
    $password = $_POST['password'];

    // Generate unique MRN
    $mrn = 'MRN' . time();

    // Hash password
    $password_hash = password_hash($password, PASSWORD_DEFAULT);

    // Validate form data
    if (!$name || !$dob || !$gender || !$address || !$contact || !$emergency_contact || !$password) {
        $message = "All fields are required!";
    } else {
        // Insert patient into database
        $query = "INSERT INTO Patients (mrn, name, date_of_birth, gender, address, contact_number, emergency_contact, password_hash) 
                  VALUES (:mrn, :name, :dob, :gender, :address, :contact, :emergency_contact, :password_hash)";
        $stmt = $pdo->prepare($query);
        $stmt->execute([ 
            ':mrn' => $mrn,
            ':name' => $name,
            ':dob' => $dob,
            ':gender' => $gender,
            ':address' => $address,
            ':contact' => $contact,
            ':emergency_contact' => $emergency_contact,
            ':password_hash' => $password_hash
        ]);
        $message = "Patient added successfully with MRN: $mrn";
    }
}

// Handle Patient Deletion
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['delete_patient'])) {
    $patient_id = $_POST['patient_id'];
    if (!is_numeric($patient_id)) {
        $message = "Invalid patient ID.";
    } else {
        // Proceed with deleting the patient
        $stmt = $pdo->prepare("DELETE FROM Patients WHERE id = :id");
        $stmt->execute([':id' => $patient_id]);
        $message = "Patient deleted successfully!";
    }
}

// Fetch Patients from Database
$stmt = $pdo->query("SELECT * FROM Patients ORDER BY id ASC");
$patients = $stmt->fetchAll(PDO::FETCH_ASSOC);
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Manage Patients | HealthHorizon</title>
    <link href="https://fonts.googleapis.com/css2?family=Roboto:wght@400;500;700&display=swap" rel="stylesheet">
    <style>
        body {
            font-family: 'Roboto', sans-serif;
            margin: 0;
            padding: 0;
            background-color: #f7f9fc;
            color: #333;
        }
        header {
            background-color: #0056b3;
            color: white;
            padding: 20px;
        }
        header .header-content {
            display: flex;
            align-items: center;
        }
        header .logo-container {
            display: flex;
            align-items: center;
            justify-content: center;
            padding: 10px;
            border: 2px solid #ffffff;
            border-radius: 10px;
            background-color: white;
            box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
            margin-right: 15px;
        }
        header img {
            height: 50px;
            width: auto;
        }
        nav {
            background-color: white;
            box-shadow: 0px 4px 8px rgba(0, 0, 0, 0.1);
            display: flex;
            justify-content: center;
            align-items: center;
            gap: 20px;
            padding: 15px 0;
        }
        nav a {
            color: #0056b3;
            text-decoration: none;
            padding: 10px 20px;
            border: 2px solid #0056b3;
            border-radius: 25px;
            font-size: 16px;
            font-weight: bold;
            transition: all 0.3s ease;
        }
        nav a:hover, nav a.active {
            background-color: #0056b3;
            color: white;
        }
        .container {
            max-width: 900px;
            margin: 30px auto;
            background: white;
            padding: 30px;
            border-radius: 10px;
            box-shadow: 0px 8px 16px rgba(0, 0, 0, 0.2);
        }
        h2 {
            color: #0056b3;
            margin-bottom: 20px;
        }
        .form-group {
            margin-bottom: 15px;
        }
        label {
            display: block;
            margin-bottom: 5px;
            font-weight: bold;
        }
        input, select, button {
            width: 100%;
            padding: 10px;
            margin: 5px 0;
            border: 1px solid #ddd;
            border-radius: 5px;
            font-size: 16px;
        }
        button {
            background-color: #0056b3;
            color: white;
            font-weight: bold;
            cursor: pointer;
            transition: all 0.3s ease;
        }
        button:hover {
            background-color: #00408a;
        }
        .message {
            font-size: 16px;
            color: green;
            margin: 10px 0;
        }
        table {
            width: 100%;
            border-collapse: collapse;
            margin-top: 20px;
        }
        th, td {
            padding: 10px;
            border: 1px solid #ddd;
            text-align: left;
        }
        th {
            background-color: #e9ecef;
            color: #0056b3;
        }
        .delete-button {
            background-color: #dc3545;
            color: white;
            border: none;
            padding: 8px 12px;
            border-radius: 5px;
            cursor: pointer;
        }
        .delete-button:hover {
            background-color: #bd2130;
        }
        footer {
            background-color: #023e8a;
            color: white;
            text-align: center;
            padding: 10px 0;
            margin-top: auto;
        }
    </style>
</head>
<body>
<header>
    <div class="header-content">
        <div class="logo-container">
            <img src="/PIC/WhatsApp Image 2024-12-08 at 15.12.54_61cd6b5b.jpg" alt="HealthHorizon Logo">
        </div>
        <h1>Manage Patients</h1>
    </div>

</header>
 <nav>
 <a href="admin_dashboard.php">Dashboard</a>
        <a href="manage_doctors.php">Manage Doctors</a>
        <a href="manage_patients.php">Manage Patients</a>
        <a href="manage_appointments.php">Manage Appointments</a>
        <a href="logs.php">Logs</a>
    </nav>
<div class="container">
    <h2>Add Patient</h2>
    <?php if ($message): ?>
        <p class="message"><?= htmlspecialchars($message) ?></p>
    <?php endif; ?>
    <form method="POST">
        <div class="form-group">
            <label for="name">Patient Name:</label>
            <input type="text" id="name" name="name" required>
        </div>
        <div class="form-group">
            <label for="dob">Date of Birth:</label>
            <input type="date" id="dob" name="dob" required>
        </div>
        <div class="form-group">
            <label for="gender">Gender:</label>
            <select id="gender" name="gender" required>
                <option value="" disabled selected>Select Gender</option>
                <option value="M">Male</option>
                <option value="F">Female</option>
            </select>
        </div>
        <div class="form-group">
            <label for="address">Address:</label>
            <input type="text" id="address" name="address" required>
        </div>
        <div class="form-group">
            <label for="contact">Contact Number:</label>
            <input type="text" id="contact" name="contact" required>
        </div>
        <div class="form-group">
            <label for="emergency_contact">Emergency Contact:</label>
            <input type="text" id="emergency_contact" name="emergency_contact" required>
        </div>
        <div class="form-group">
            <label for="password">Password:</label>
            <input type="password" id="password" name="password" required>
        </div>
        <button type="submit" name="add_patient">Add Patient</button>
    </form>
    <h2>Existing Patients</h2>
    <table>
        <tr>
            <th>ID</th>
            <th>MRN</th>
            <th>Name</th>
            <th>Contact</th>
            <th>Actions</th>
        </tr>
        <?php foreach ($patients as $patient): ?>
            <tr>
                <td><?= htmlspecialchars($patient['id']) ?></td>
                <td><?= htmlspecialchars($patient['mrn']) ?></td>
                <td><?= htmlspecialchars($patient['name']) ?></td>
                <td><?= htmlspecialchars($patient['contact_number']) ?></td>
                <td>
                    <form method="POST" style="display:inline;">
                        <input type="hidden" name="patient_id" value="<?= $patient['id'] ?>">
                        <button type="submit" name="delete_patient" class="delete-button">Delete</button>
                    </form>
                </td>
            </tr>
        <?php endforeach; ?>
    </table>
</div>
<footer>
    &copy; 2024 HealthHorizon. All Rights Reserved.
</footer>
</body>
</html>
