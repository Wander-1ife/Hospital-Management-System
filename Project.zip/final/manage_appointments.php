<?php
session_start();
require 'database.php';

if (!isset($_SESSION['user_id']) || $_SESSION['role'] !== 'Admin') {
    header("Location: login.php");
    exit();
}

$message = '';

// Handle deletion of an appointment
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['delete_appointment_id'])) {
    $appointment_id = $_POST['delete_appointment_id'];
    if (!is_numeric($appointment_id)) {
        $message = "Invalid appointment ID.";
    } else {
        $deleteStmt = $pdo->prepare("DELETE FROM appointments WHERE appointment_id = :appointment_id");
        $deleteStmt->execute(['appointment_id' => $appointment_id]);
        $message = "Appointment deleted successfully!";
    }
}

// Fetch appointments
$stmt = $pdo->query("
    SELECT 
        a.appointment_id, 
        a.appointment_date, 
        a.status, 
        p.name AS patient_name, 
        d.name AS doctor_name 
    FROM appointments a
    JOIN patients p ON a.patient_id = p.id
    JOIN doctors d ON a.doctor_id = d.id
    ORDER BY a.appointment_date ASC
");
$appointments = $stmt->fetchAll(PDO::FETCH_ASSOC);
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Manage Appointments | HealthHorizon</title>
    <link href="https://fonts.googleapis.com/css2?family=Roboto:wght@400;500;700&display=swap" rel="stylesheet">
    <style>
        body {
            font-family: 'Roboto', sans-serif;
            margin: 0;
            padding: 0;
            background-color: #f7f9fc;
            color: #333;
            display: flex;
            flex-direction: column;
            min-height: 100vh;
        }
        header {
            background-color: #0056b3;
            color: white;
            padding: 20px;
        }
        header .header-content {
            display: flex;
            align-items: center;
        }
        header .logo-container {
            display: flex;
            align-items: center;
            justify-content: center;
            padding: 10px;
            border: 2px solid #ffffff;
            border-radius: 10px;
            background-color: white;
            box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
            margin-right: 15px;
        }
        header img {
            height: 50px;
            width: auto;
        }
        nav {
            background-color: white;
            box-shadow: 0px 4px 8px rgba(0, 0, 0, 0.1);
            display: flex;
            justify-content: center;
            align-items: center;
            gap: 20px;
            padding: 15px 0;
        }
        nav a {
            color: #0056b3;
            text-decoration: none;
            padding: 10px 20px;
            border: 2px solid #0056b3;
            border-radius: 25px;
            font-size: 16px;
            font-weight: bold;
            transition: all 0.3s ease;
        }
        nav a:hover, nav a.active {
            background-color: #0056b3;
            color: white;
        }
        .content {
            flex: 1;
            max-width: 900px;
            margin: 30px auto;
            background: white;
            padding: 30px;
            border-radius: 10px;
            box-shadow: 0px 8px 16px rgba(0, 0, 0, 0.2);
        }
        h2 {
            color: #0056b3;
            margin-bottom: 20px;
        }
        .message {
            font-size: 16px;
            color: green;
            margin: 10px 0;
        }
        table {
            width: 100%;
            border-collapse: collapse;
            margin-top: 20px;
        }
        th, td {
            padding: 10px;
            border: 1px solid #ddd;
            text-align: left;
        }
        th {
            background-color: #e9ecef;
            color: #0056b3;
        }
        .delete-button {
            background-color: #dc3545;
            color: white;
            border: none;
            padding: 8px 12px;
            border-radius: 5px;
            cursor: pointer;
        }
        .delete-button:hover {
            background-color: #bd2130;
        }
        footer {
            background-color: #023e8a;
            color: white;
            text-align: center;
            padding: 10px 0;
            font-size: 14px;
            margin-top: auto;
        }
    </style>
</head>
<body>
<header>
    <div class="header-content">
        <div class="logo-container">
            <img src="/PIC/WhatsApp Image 2024-12-08 at 15.12.54_61cd6b5b.jpg" alt="HealthHorizon Logo">
        </div>
        <h1>Manage Appointments</h1>
    </div>
</header>
 <nav>	
 <a href="admin_dashboard.php">Dashboard</a>
        <a href="manage_doctors.php">Manage Doctors</a>
        <a href="manage_patients.php">Manage Patients</a>
        <a href="manage_appointments.php">Manage Appointments</a>
        <a href="logs.php">Logs</a>
    </nav>
<div class="content">
    <h2>Manage Appointments</h2>
    <?php if ($message): ?>
        <p class="message"><?= htmlspecialchars($message) ?></p>
    <?php endif; ?>
    <?php if (empty($appointments)): ?>
        <p>No appointments found.</p>
    <?php else: ?>
        <table>
            <thead>
                <tr>
                    <th>ID</th>
                    <th>Patient Name</th>
                    <th>Doctor Name</th>
                    <th>Date</th>
                    <th>Status</th>
                    <th>Actions</th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($appointments as $appointment): ?>
                    <tr>
                        <td><?= htmlspecialchars($appointment['appointment_id']) ?></td>
                        <td><?= htmlspecialchars($appointment['patient_name']) ?></td>
                        <td><?= htmlspecialchars($appointment['doctor_name']) ?></td>
                        <td><?= htmlspecialchars($appointment['appointment_date']) ?></td>
                        <td><?= htmlspecialchars($appointment['status']) ?></td>
                        <td>
                            <form method="POST" style="display:inline;">
                                <input type="hidden" name="delete_appointment_id" value="<?= htmlspecialchars($appointment['appointment_id']) ?>">
                                <button type="submit" class="delete-button">Delete</button>
                            </form>
                        </td>
                    </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
    <?php endif; ?>
</div>
<footer>
    &copy; 2024 HealthHorizon. All Rights Reserved.
</footer>
</body>
</html>
