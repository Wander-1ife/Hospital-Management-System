<?php
session_start();
require 'database.php';

// Ensure the user is logged in and is a doctor
if (!isset($_SESSION['user_id']) || $_SESSION['role'] !== 'Doctor') {
    header("Location: login.php");
    exit();
}

$doctor_id = $_SESSION['user_id'];

// Check if visit_id is provided via GET
if (!isset($_GET['visit_id']) || empty($_GET['visit_id'])) {
    die("Visit ID is required to create an invoice.");
}

$visit_id = $_GET['visit_id'];

// Fetch visit details for validation
$queryVisit = "
    SELECT 
        v.id AS visit_id, 
        v.patient_id, 
        v.doctor_id, 
        v.date, 
        p.name AS patient_name, 
        p.mrn 
    FROM visits v
    JOIN patients p ON v.patient_id = p.id
    WHERE v.id = :visit_id AND v.doctor_id = :doctor_id";
$stmt = $pdo->prepare($queryVisit);
$stmt->execute(['visit_id' => $visit_id, 'doctor_id' => $doctor_id]);
$visit = $stmt->fetch(PDO::FETCH_ASSOC);

if (!$visit) {
    die("Invalid visit or you are not authorized to create an invoice for this visit.");
}

// Check if an invoice already exists for this visit_id
$queryInvoiceCheck = "SELECT * FROM invoices WHERE visit_id = :visit_id";
$stmtCheck = $pdo->prepare($queryInvoiceCheck);
$stmtCheck->execute(['visit_id' => $visit_id]);
$existingInvoice = $stmtCheck->fetch(PDO::FETCH_ASSOC);

if ($existingInvoice) {
    die("An invoice has already been created for this visit.");
}

// Handle invoice creation
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['create_invoice'])) {
    $doctor_fee = $_POST['doctor_fee'];
    $hospital_charges = $_POST['hospital_charges'];

    // Insert invoice into the database
    $queryInvoice = "INSERT INTO invoices (visit_id, doctor_fee, hospital_charges) 
                     VALUES (:visit_id, :doctor_fee, :hospital_charges)";
    $stmt = $pdo->prepare($queryInvoice);
    $stmt->execute([
        'visit_id' => $visit_id,
        'doctor_fee' => $doctor_fee,
        'hospital_charges' => $hospital_charges
    ]);

    $message = "Invoice created successfully!";
    header("Location: doctors_patient.php"); // Redirect back to patient list
    exit();
}

?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Create Invoice | HealthHorizon</title>
    <link href="https://fonts.googleapis.com/css2?family=Roboto:wght@400;500;700&display=swap" rel="stylesheet">
    <style>
        body {
            font-family: 'Roboto', sans-serif;
            margin: 0;
            padding: 0;
            background-color: #f7f9fc;
            color: #333;
        }
        header {
            background-color: #0056b3;
            color: white;
            padding: 20px;
            display: flex;
            align-items: center;
        }
        .header-left {
            display: flex;
            align-items: center;
            background-color: white;
            padding: 10px;
            border-radius: 10px;
            box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
            margin-right: 20px;
        }
        .logo {
            height: 50px;
            width: auto;
        }
        h1 {
            font-size: 24px;
            margin: 0;
        }
        .container {
            max-width: 600px;
            margin: 30px auto;
            background: white;
            padding: 30px;
            border-radius: 10px;
            box-shadow: 0px 8px 16px rgba(0, 0, 0, 0.2);
        }
        .form-group {
            margin-bottom: 20px;
        }
        label {
            display: block;
            margin-bottom: 8px;
            font-weight: bold;
        }
        input {
            width: 100%;
            padding: 10px;
            border: 1px solid #ddd;
            border-radius: 5px;
            font-size: 16px;
        }
        .btn {
            background-color: #0056b3;
            color: white;
            border: none;
            padding: 10px 20px;
            border-radius: 5px;
            font-size: 16px;
            cursor: pointer;
            transition: all 0.3s ease;
        }
        .btn:hover {
            background-color: #00408a;
        }
        .message {
            color: green;
            margin-bottom: 15px;
        }
        h2 {
            color: #0056b3;
            margin-bottom: 20px;
        }
    </style>
</head>
<body>
    <header>
        <div class="header-left">
            <img src="/PIC/WhatsApp Image 2024-12-08 at 15.12.54_61cd6b5b.jpg" alt="HealthHorizon Logo" class="logo">
        </div>
        <h1>Create Invoice</h1>
    </header>
    <div class="container">
        <?php if (!empty($message)): ?>
            <p class="message"><?= htmlspecialchars($message) ?></p>
        <?php endif; ?>

        <form method="POST">
            <input type="hidden" name="visit_id" value="<?= htmlspecialchars($visit_id ?? '') ?>">

            <div class="form-group">
                <label for="doctor_fee">Doctor Fee (in $):</label>
                <input type="number" step="0.01" name="doctor_fee" id="doctor_fee" required>
            </div>

            <div class="form-group">
                <label for="hospital_charges">Hospital Charges (in $):</label>
                <input type="number" step="0.01" name="hospital_charges" id="hospital_charges" required>
            </div>

            <button type="submit" name="create_invoice" class="btn">Submit Invoice</button>
        </form>
    </div>
</body>
</html>
