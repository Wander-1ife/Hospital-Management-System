<?php
require_once 'database.php'; // Include database connection

// Initialize message
$error = '';
$success = '';

// Handle Deletion
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $admin_id = $_POST['admin_id'];

    // Check if the admin_id is 2
    if ($admin_id == 2) {
        $error = "Admin with ID 2 cannot be deleted.";
    } else {
        // Proceed with deletion if admin_id is not 2
        if (!empty($admin_id)) {
            // SQL query to delete the admin based on the ID
            $sql = "DELETE FROM admins WHERE id = :admin_id";

            try {
                $stmt = $pdo->prepare($sql);
                $stmt->execute([':admin_id' => $admin_id]);

                // Check if any rows were affected (deleted)
                if ($stmt->rowCount() > 0) {
                    $success = "Admin deleted successfully!";
                } else {
                    $error = "No admin found with the given ID.";
                }
            } catch (PDOException $e) {
                $error = "Error during deletion: " . $e->getMessage();
            }
        } else {
            $error = "Admin ID is required.";
        }
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Delete Admin | HealthHorizon</title>
    <link href="https://fonts.googleapis.com/css2?family=Roboto:wght@400;500;700&display=swap" rel="stylesheet">
    <style>
        body {
            font-family: 'Roboto', sans-serif;
            margin: 0;
            padding: 0;
            background-color: #f7f9fc;
            display: flex;
            justify-content: center;
            align-items: center;
            height: 100vh;
            color: #333;
        }
        .form-container {
            background: #ffffff;
            padding: 30px 40px;
            border-radius: 10px;
            box-shadow: 0px 8px 16px rgba(0, 0, 0, 0.2);
            width: 100%;
            max-width: 500px;
            text-align: center;
        }
        h2 {
            color: #0056b3;
            margin-bottom: 20px;
            font-size: 24px;
        }
        label {
            font-weight: 600;
            margin-top: 10px;
            display: block;
            text-align: left;
        }
        input, button {
            width: 100%;
            padding: 12px;
            margin: 10px 0;
            border: 1px solid #ddd;
            border-radius: 5px;
            font-size: 16px;
        }
        button {
            background-color: #ff4e4e;
            color: white;
            border: none;
            cursor: pointer;
            font-size: 18px;
            transition: background-color 0.3s ease;
        }
        button:hover {
            background-color: #d43f3f;
        }
        .back-button {
            margin-top: 15px;
            display: inline-block;
            background-color: #023e8a;
            color: white;
            text-decoration: none;
            padding: 10px 20px;
            border-radius: 5px;
            font-size: 16px;
            transition: background-color 0.3s ease;
        }
        .back-button:hover {
            background-color: #00b4d8;
        }
        .message {
            margin-top: 20px;
            font-size: 16px;
        }
        .success {
            color: green;
        }
        .error {
            color: red;
        }
    </style>
</head>
<body>
    <div class="form-container">
        <h2>Delete Admin | HealthHorizon</h2>
        <form method="POST" action="">
            <label for="admin_id">Admin ID</label>
            <input type="text" id="admin_id" name="admin_id" placeholder="Enter Admin ID" required>

            <button type="submit">Delete Admin</button>
        </form>

        <!-- Display Messages -->
        <div class="message">
            <?php if (!empty($error)) echo "<p class='error'>$error</p>"; ?>
            <?php if (!empty($success)) echo "<p class='success'>$success</p>"; ?>
        </div>

        <!-- Back Button -->
        <a href="index.php" class="back-button">← Back to Main Page</a>
    </div>
</body>
</html>
