<?php
session_start();
require 'database.php';

// Ensure the user is logged in and is a doctor
if (!isset($_SESSION['user_id']) || $_SESSION['role'] !== 'Doctor') {
    header("Location: login.php");
    exit();
}

$doctor_id = $_SESSION['user_id'];

// Fetch appointments and patient details for this doctor
$queryAppointments = "
    SELECT 
        a.appointment_id, 
        a.appointment_date, 
        a.status, 
        p.name AS patient_name, 
        p.mrn, 
        p.contact_number, 
        v.symptoms, 
        v.diagnosis, 
        v.prescription
    FROM appointments a
    JOIN patients p ON a.patient_id = p.id
    LEFT JOIN visits v ON v.patient_id = a.patient_id AND v.doctor_id = a.doctor_id AND v.date = a.appointment_date
    WHERE a.doctor_id = :doctor_id
    ORDER BY a.appointment_date DESC";
$stmt = $pdo->prepare($queryAppointments);
$stmt->execute(['doctor_id' => $doctor_id]);
$appointments = $stmt->fetchAll(PDO::FETCH_ASSOC);

// Handle appointment status updates
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['update_status'])) {
    $appointment_id = $_POST['appointment_id'];
    $status = $_POST['update_status']; // 'Accepted' or 'Rejected'

    $updateStatusQuery = "UPDATE appointments 
                          SET status = :status 
                          WHERE appointment_id = :appointment_id AND doctor_id = :doctor_id";
    $stmt = $pdo->prepare($updateStatusQuery);
    $stmt->execute([
        'status' => $status,
        'appointment_id' => $appointment_id,
        'doctor_id' => $doctor_id
    ]);
    $message = "Status updated successfully!";
}

// Handle adding a prescription and diagnosis
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['add_prescription'])) {
    $appointment_id = $_POST['selected_appointment'];
    $prescription = $_POST['prescription'];
    $diagnosis = $_POST['diagnosis'];

    $updateVisitQuery = "
        UPDATE visits
        SET diagnosis = :diagnosis, prescription = :prescription
        WHERE appointment_id = :appointment_id";
    $stmt = $pdo->prepare($updateVisitQuery);
    $stmt->execute([
        'diagnosis' => $diagnosis,
        'prescription' => $prescription,
        'appointment_id' => $appointment_id
    ]);
    $message = "Prescription and diagnosis updated successfully!";
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Manage Appointments | HealthHorizon</title>
    <link href="https://fonts.googleapis.com/css2?family=Roboto:wght@400;500;700&display=swap" rel="stylesheet">
    <style>
        body {
            font-family: 'Roboto', sans-serif;
            margin: 0;
            padding: 0;
            background-color: #f7f9fc;
            color: #333;
        }
        header {
            background-color: #0056b3;
            color: white;
            padding: 20px;
            display: flex;
            align-items: center;
        }
        .header-left {
            display: flex;
            align-items: center;
            background-color: white;
            padding: 10px;
            border-radius: 10px;
            box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
            margin-right: 20px;
        }
        .logo {
            height: 50px;
            width: auto;
        }
        h1 {
            margin: 0;
            font-size: 24px;
        }
        nav {
            background-color: white;
            box-shadow: 0px 4px 8px rgba(0, 0, 0, 0.1);
            display: flex;
            justify-content: center;
            align-items: center;
            gap: 20px;
            padding: 15px 0;
        }
        nav a {
            color: #0056b3;
            text-decoration: none;
            padding: 10px 20px;
            border: 2px solid #0056b3;
            border-radius: 25px;
            font-size: 16px;
            font-weight: bold;
            transition: all 0.3s ease;
        }
        nav a:hover {
            background-color: #0056b3;
            color: white;
        }
        .container {
            max-width: 900px;
            margin: 30px auto;
            background: white;
            padding: 30px;
            border-radius: 10px;
            box-shadow: 0px 8px 16px rgba(0, 0, 0, 0.2);
        }
        h2 {
            color: #0056b3;
            font-size: 22px;
            margin-bottom: 20px;
        }
        table {
            width: 100%;
            border-collapse: collapse;
            margin: 20px 0;
        }
        th, td {
            padding: 10px;
            border: 1px solid #ddd;
            text-align: center;
        }
        textarea, select {
            width: 100%;
            padding: 10px;
            margin: 10px 0;
            border: 1px solid #ddd;
            border-radius: 5px;
            font-size: 16px;
            height: 100px; /* Ensures all text areas are of the same height */
        }
        .btn {
            background-color: #0056b3;
            color: white;
            border: none;
            padding: 10px 20px;
            border-radius: 5px;
            cursor: pointer;
            font-size: 16px;
            transition: all 0.3s ease;
        }
        .btn:hover {
            background-color: #00408a;
        }
        .btn-danger {
            background-color: #dc3545;
        }
        .btn-danger:hover {
            background-color: #c82333;
        }
        .message {
            margin: 10px 0;
            padding: 10px;
            color: green;
            border: 1px solid green;
            border-radius: 5px;
            background-color: #e6ffe6;
        }
    </style>
    <script>
        document.addEventListener('DOMContentLoaded', function () {
            const selectElement = document.getElementById('selected_appointment');
            selectElement.addEventListener('change', function() {
                var selectedOption = this.options[this.selectedIndex];
                var symptoms = selectedOption.getAttribute('data-symptoms');
                document.getElementById('symptoms').value = symptoms;
            });
        });
    </script>
</head>
<body>
    <header>
        <div class="header-left">
            <img src="/PIC/WhatsApp Image 2024-12-08 at 15.12.54_61cd6b5b.jpg" alt="HealthHorizon Logo" class="logo">
        </div>
        <h1>Manage Appointments</h1>
    </header>
    <nav>
         <a href="doctor_dashboard.php">Dashboard</a>
        <a href="doctors_patient.php">Manage Patients</a>
        <a href="doctors_appointments.php">Manage Appointments</a>
        <a href="edit_doctor.php">Edit Info</a>
        <a href="logout.php">Logout</a>
    </nav>
    <div class="container">
        <?php if (!empty($message)): ?>
            <div class="message"><?= htmlspecialchars($message) ?></div>
        <?php endif; ?>
        <h2>Appointments</h2>
        <table>
            <tr>
                <th>Date</th>
                <th>Patient</th>
                <th>MRN</th>
                <th>Contact</th>
                <th>Status</th>
                <th>Actions</th>
            </tr>
            <?php foreach ($appointments as $appointment): ?>
                <tr>
                    <td><?= htmlspecialchars($appointment['appointment_date']) ?></td>
                    <td><?= htmlspecialchars($appointment['patient_name']) ?></td>
                    <td><?= htmlspecialchars($appointment['mrn']) ?></td>
                    <td><?= htmlspecialchars($appointment['contact_number']) ?></td>
                    <td><?= htmlspecialchars($appointment['status']) ?></td>
                    <td>
                        <form method="POST" style="display: inline;">
                            <input type="hidden" name="appointment_id" value="<?= $appointment['appointment_id'] ?>">
                            <button type="submit" name="update_status" value="Accepted" class="btn">Accept</button>
                            <button type="submit" name="update_status" value="Rejected" class="btn btn-danger">Reject</button>
                        </form>
                    </td>
                </tr>
            <?php endforeach; ?>
        </table>

        <!-- Interact with Patient Section -->
        <div>
            <h2>Interact with Patient</h2>
            <form method="POST">
                <label for="selected_appointment">Select Appointment:</label>
                <select name="selected_appointment" id="selected_appointment">
                    <option value="">Select an Appointment</option>
                    <?php foreach ($appointments as $appointment): ?>
                        <option value="<?= $appointment['appointment_id'] ?>" data-symptoms="<?= htmlspecialchars($appointment['symptoms']) ?>">
                            <?= htmlspecialchars($appointment['appointment_date'] . " - " . $appointment['patient_name']) ?>
                        </option>
                    <?php endforeach; ?>
                </select>

                <label for="symptoms">Patient Symptoms:</label>
                <textarea name="symptoms" id="symptoms" readonly></textarea>

                <label for="diagnosis">Diagnosis:</label>
                <textarea name="diagnosis" id="diagnosis" required></textarea>

                <label for="prescription">Prescription:</label>
                <textarea name="prescription" id="prescription" required></textarea>

                <button type="submit" name="add_prescription" class="btn">Submit</button>
            </form>
        </div>
    </div>
</body>
</html>