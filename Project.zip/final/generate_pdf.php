<?php
session_start();
require __DIR__ . '/Tcpdf/TCPDF-main/tcpdf.php';

require 'database.php';

if (!isset($_SESSION['user_id'])) {
    die("Access denied");
}

$report_id = filter_input(INPUT_GET, 'report_id', FILTER_VALIDATE_INT);
if (!$report_id) {
    die("Invalid report ID");
}

$stmt = $pdo->prepare("SELECT r.*, d.name AS doctor_name, p.name AS patient_name 
                      FROM Reports r
                      JOIN Doctors d ON r.doctor_id = d.id
                      JOIN Patients p ON r.patient_id = p.id
                      WHERE r.id = :report_id AND r.patient_id = :patient_id");
$stmt->execute([
    'report_id' => $report_id,
    'patient_id' => $_SESSION['user_id']
]);
$report = $stmt->fetch(PDO::FETCH_ASSOC);

if (!$report) {
    die("Report not found.");
}

$pdf = new TCPDF();
$pdf->AddPage();
$pdf->SetFont('Helvetica', '', 12);
$html = "
    <h1>Blood Test Report</h1>
    <p><strong>Patient Name:</strong> {$report['patient_name']}</p>
    <p><strong>Date:</strong> {$report['report_date']}</p>
    <p><strong>Requested By:</strong> {$report['doctor_name']}</p>
    <p><strong>Description:</strong> {$report['description']}</p>
";
$pdf->writeHTML($html);
$pdf->Output("blood_test_report_{$report_id}.pdf", 'I');
?>
