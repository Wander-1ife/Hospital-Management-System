<?php
require_once 'database.php'; // Include database connection

// Initialize messages
$error = '';
$success = '';

// Handle Sign Up
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $name = $_POST['name'];
    $dob = $_POST['dob'];
    $gender = $_POST['gender'];
    $address = $_POST['address'];
    $contact = $_POST['contact'];
    $emergency_contact = $_POST['emergency_contact'];
    $password = $_POST['password'];

    // Generate a unique MRN
    $mrn = 'MRN' . time();

    // Hash the password
    $password_hash = password_hash($password, PASSWORD_DEFAULT);

    // Insert patient data into the database
    $sql = "INSERT INTO Patients (mrn, name, date_of_birth, gender, address, contact_number, emergency_contact, password_hash) 
            VALUES (:mrn, :name, :dob, :gender, :address, :contact, :emergency_contact, :password_hash)";
    try {
        $stmt = $pdo->prepare($sql);
        $stmt->execute([
            ':mrn' => $mrn,
            ':name' => $name,
            ':dob' => $dob,
            ':gender' => $gender,
            ':address' => $address,
            ':contact' => $contact,
            ':emergency_contact' => $emergency_contact,
            ':password_hash' => $password_hash
        ]);

        // Show success message
        $success = "Registration successful! Your MRN is: <strong>$mrn</strong>";
    } catch (PDOException $e) {
        // Log the detailed error for internal tracking
        error_log("Database error during registration: " . $e->getMessage());

        // Show a generic error message to the user
        $error = "An error occurred. Please try again later.";
    } catch (Exception $e) {
        // Log any general errors for internal tracking
        error_log("General error: " . $e->getMessage());

        // Show a generic error message to the user
        $error = "An error occurred. Please try again later.";
    }
}
?><!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Sign Up | HealthHorizon</title>
    <link href="https://fonts.googleapis.com/css2?family=Roboto:wght@400;500;700&display=swap" rel="stylesheet">
    <style>
        body {
            font-family: 'Roboto', sans-serif;
            margin: 0;
            padding: 0;
            background-color: #f7f9fc;
            display: flex;
            justify-content: center;
            align-items: center;
            height: 100vh;
            color: #333;
        }
        .form-container {
            background: #ffffff;
            padding: 30px 40px;
            border-radius: 10px;
            box-shadow: 0px 8px 16px rgba(0, 0, 0, 0.2);
            width: 100%;
            max-width: 500px;
            text-align: center;
        }
        h2 {
            color: #0056b3;
            margin-bottom: 20px;
            font-size: 24px;
        }
        input, select, button {
            width: 100%;
            padding: 12px;
            margin: 10px 0;
            border: 1px solid #ddd;
            border-radius: 5px;
            font-size: 16px;
        }
        button {
            background-color: #0056b3;
            color: white;
            border: none;
            cursor: pointer;
            font-size: 18px;
            transition: background-color 0.3s ease;
        }
        button:hover {
            background-color: #00408a;
        }
        .back-button {
            margin-top: 15px;
            display: inline-block;
            background-color: #023e8a;
            color: white;
            text-decoration: none;
            padding: 10px 20px;
            border-radius: 5px;
            font-size: 16px;
            transition: background-color 0.3s ease;
        }
        .back-button:hover {
            background-color: #00b4d8;
        }
        .message {
            margin-top: 20px;
            font-size: 16px;
        }
        .success {
            color: green;
        }
        .error {
            color: red;
        }
    </style>
</head>
<body>
    <div class="form-container">
        <h2>Join HealthHorizon</h2>
        <form method="POST" action="">
            <input type="text" name="name" placeholder="Full Name" required>
            <input type="date" name="dob" required>
            <select name="gender" required>
                <option value="" disabled selected>Select Gender</option>
                <option value="M">Male</option>
                <option value="F">Female</option>
            </select>
            <input type="text" name="address" placeholder="Address" required>
            <input type="text" name="contact" placeholder="Contact Number" required>
            <input type="text" name="emergency_contact" placeholder="Emergency Contact" required>
            <input type="password" name="password" placeholder="Create Password" required>
            <button type="submit">Sign Up</button>
        </form>

        <!-- Display Messages -->
        <div class="message">
            <?php if (!empty($error)) echo "<p class='error'>$error</p>"; ?>
            <?php if (!empty($success)) echo "<p class='success'>$success</p>"; ?>
        </div>

        <!-- Back and Login Buttons -->
        <a href="index.php" class="back-button">← Back to Main Page</a>
    </div>
</body>
</html>
