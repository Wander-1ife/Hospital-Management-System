<?php
session_start();
require 'database.php';

if (!isset($_SESSION['user_id']) || $_SESSION['role'] !== 'Admin') {
    header("Location: login.php");
    exit();
}

$message = '';
$admin_id = $_SESSION['user_id'];

// Fetch current admin details
$stmt = $pdo->prepare("SELECT name, username FROM Admins WHERE id = :admin_id");
$stmt->execute(['admin_id' => $admin_id]);
$admin = $stmt->fetch(PDO::FETCH_ASSOC);

// Handle form submission
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $name = $_POST['name'];
    $username = $_POST['username'];
    $password = $_POST['password'];

    try {
        // Check if username is unique
        $usernameCheck = $pdo->prepare("SELECT COUNT(*) FROM Admins WHERE username = :username AND id != :admin_id");
        $usernameCheck->execute(['username' => $username, 'admin_id' => $admin_id]);
        if ($usernameCheck->fetchColumn() > 0) {
            $message = "Username already exists. Please choose another.";
        } else {
            // Update admin details
            $updateQuery = "UPDATE Admins SET name = :name, username = :username";
            $params = ['name' => $name, 'username' => $username, 'admin_id' => $admin_id];

            // If password is provided, hash and update it
            if (!empty($password)) {
                $password_hash = password_hash($password, PASSWORD_DEFAULT);
                $updateQuery .= ", password_hash = :password_hash";
                $params['password_hash'] = $password_hash;
            }

            $updateQuery .= " WHERE id = :admin_id";
            $stmt = $pdo->prepare($updateQuery);
            $stmt->execute($params);

            $message = "Profile updated successfully!";
            $_SESSION['name'] = $name; // Update session name
        }
    } catch (PDOException $e) {
        $message = "Error: " . $e->getMessage();
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Edit Profile</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            margin: 0;
            padding: 0;
            background-color: #f4f4f4;
            display: flex;
            justify-content: center;
            align-items: center;
            height: 100vh;
        }
        .form-container {
            background: white;
            padding: 20px 30px;
            border-radius: 10px;
            box-shadow: 0px 4px 8px rgba(0, 0, 0, 0.2);
            width: 100%;
            max-width: 400px;
        }
        h2 {
            color: #007BFF;
            text-align: center;
        }
        label {
            font-size: 16px;
            margin-top: 10px;
            display: block;
            color: #333;
        }
        input, button {
            width: calc(100% - 20px);
            padding: 10px;
            margin: 10px 0;
            border-radius: 5px;
            border: 1px solid #ddd;
            font-size: 16px;
        }
        button {
            background-color: #007BFF;
            color: white;
            border: none;
            cursor: pointer;
        }
        button:hover {
            background-color: #0056b3;
        }
        .back-btn {
            background-color: #6c757d;
        }
        .back-btn:hover {
            background-color: #5a6268;
        }
        .message {
            text-align: center;
            margin-top: 10px;
            color: green;
        }
        .error {
            color: red;
        }
    </style>
</head>
<body>
    <div class="form-container">
        <h2>Edit Profile</h2>
        <?php if ($message): ?>
            <p class="<?= strpos($message, 'Error') === false ? 'message' : 'error' ?>">
                <?= htmlspecialchars($message) ?>
            </p>
        <?php endif; ?>
        <form method="POST">
            <label for="name">Full Name</label>
            <input type="text" name="name" id="name" value="<?= htmlspecialchars($admin['name']) ?>" required>

            <label for="username">Username</label>
            <input type="text" name="username" id="username" value="<?= htmlspecialchars($admin['username']) ?>" required>

            <label for="password">New Password (optional)</label>
            <input type="password" name="password" id="password" placeholder="New Password (optional)">

            <button type="submit">Update</button>
        </form>
        <a href="admin_dashboard.php">
            <button class="back-btn">Go Back</button>
        </a>
    </div>
</body>
</html>
