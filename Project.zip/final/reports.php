<?php
session_start();
require 'database.php';

if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit();
}

$patient_id = $_SESSION['user_id'];
$query = "SELECT r.*, d.name AS doctor_name 
          FROM Reports r 
          JOIN Doctors d ON r.doctor_id = d.id
          WHERE r.patient_id = :patient_id 
          ORDER BY r.report_date DESC";
$stmt = $pdo->prepare($query);
$stmt->execute(['patient_id' => $patient_id]);
$reports = $stmt->fetchAll(PDO::FETCH_ASSOC);
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Medical Reports</title>
    <style>
        body, header, nav, .content {
            font-family: Arial, sans-serif;
        }
        header {
            background-color: #0056b3;
            color: white;
            padding: 20px;
            text-align: center;
        }
        nav {
            background-color: #007BFF;
            text-align: center;
            padding: 10px;
        }
        nav a {
            color: white;
            text-decoration: none;
            margin: 0 10px;
            padding: 10px 20px;
            border-radius: 5px;
            background-color: #0066cc;
        }
        nav a:hover {
            background-color: #004c99;
        }
        .content {
            max-width: 800px;
            margin: auto;
            background: white;
            padding: 20px;
            border-radius: 8px;
            box-shadow: 0px 4px 8px rgba(0, 0, 0, 0.2);
        }
        .report-item {
            border: 1px solid #ddd;
            padding: 10px;
            margin-bottom: 10px;
            border-radius: 5px;
        }
        .report-item h3 {
            margin: 0;
            color: #0056b3;
        }
        .btn-generate {
            background-color: #28a745;
            color: white;
            text-decoration: none;
            padding: 5px 10px;
            border-radius: 5px;
            display: inline-block;
        }
        .btn-generate:hover {
            background-color: #218838;
        }
    </style>
</head>
<body>
    <header>Welcome to Your Medical Reports</header>
    <nav>
        <a href="patient_dashboard.php">Patient Information</a>
        <a href="appointments.php">Appointments</a>
        <a href="history.php">Visit History</a>
        <a href="reports.php" class="active">Medical Reports</a>
    </nav>
    <div class="content">
        <h2>Your Medical Reports</h2>
        <?php if (empty($reports)): ?>
            <p>No medical reports found.</p>
        <?php else: ?>
            <?php foreach ($reports as $report): ?>
                <div class="report-item">
                    <h3><?= htmlspecialchars($report['type']) ?> Report</h3>
                    <p><strong>Date:</strong> <?= htmlspecialchars($report['report_date']) ?></p>
                    <p><strong>Requested By:</strong> <?= htmlspecialchars($report['doctor_name']) ?></p>
                    <p><strong>Description:</strong> <?= htmlspecialchars($report['description']) ?></p>
                    <a href="generate_pdf.php?report_id=<?= $report['id'] ?>" class="btn-generate" target="_blank">Generate PDF</a>
                </div>
            <?php endforeach; ?>
        <?php endif; ?>
    </div>
</body>
</html>
