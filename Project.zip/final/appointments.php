<?php
session_start();
require 'database.php';

// Ensure the user is logged in
if (!isset($_SESSION['user_id']) || $_SESSION['role'] !== 'Patient') {
    header("Location: login.php");
    exit();
}

$patient_id = $_SESSION['user_id'];

// Fetch appointments for the patient
$stmt = $pdo->prepare("
    SELECT 
        a.appointment_id, 
        a.appointment_date, 
        a.status, 
        a.history, 
        d.name AS doctor_name, 
        s.specialty_name 
    FROM appointments a 
    JOIN doctors d ON a.doctor_id = d.id 
    JOIN specialties s ON d.specialty_id = s.id 
    WHERE a.patient_id = :patient_id 
    ORDER BY a.appointment_date DESC
");
$stmt->execute(['patient_id' => $patient_id]);
$appointments = $stmt->fetchAll(PDO::FETCH_ASSOC);

// Fetch doctors and specialties for appointment booking
$doctors = $pdo->query("SELECT id, name, specialty_id FROM doctors")->fetchAll(PDO::FETCH_ASSOC);
$specialties = $pdo->query("SELECT id, specialty_name FROM specialties")->fetchAll(PDO::FETCH_ASSOC);

// Handle appointment booking
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['book_appointment'])) {
    $specialty_id = $_POST['specialty_id'];
    $doctor_id = $_POST['doctor_id'];
    $appointment_date = $_POST['appointment_date'];

    $insertQuery = "INSERT INTO appointments (patient_id, doctor_id, appointment_date, status) 
                    VALUES (:patient_id, :doctor_id, :appointment_date, 'Pending')";
    $stmt = $pdo->prepare($insertQuery);
    $stmt->execute([
        'patient_id' => $patient_id,
        'doctor_id' => $doctor_id,
        'appointment_date' => $appointment_date
    ]);
    header("Location: appointments.php");
    exit();
}

// Handle interaction submission
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['submit_interaction'])) {
    $appointment_id = $_POST['appointment_id'];
    $symptoms = $_POST['symptoms'];
    $history = $_POST['history'];

    $stmt = $pdo->prepare("
        SELECT patient_id, doctor_id, appointment_date 
        FROM appointments 
        WHERE appointment_id = :appointment_id AND status = 'Accepted'
    ");
    $stmt->execute(['appointment_id' => $appointment_id]);
    $appointment = $stmt->fetch(PDO::FETCH_ASSOC);

    if ($appointment) {
        $updateAppointmentQuery = "UPDATE appointments 
                                   SET history = :history 
                                   WHERE appointment_id = :appointment_id AND status = 'Accepted'";
        $stmt = $pdo->prepare($updateAppointmentQuery);
        $stmt->execute([
            'history' => $history,
            'appointment_id' => $appointment_id
        ]);

        $insertVisitQuery = "
            INSERT INTO visits (appointment_id,patient_id, doctor_id, date, symptoms) 
            VALUES (:appointment_id,:patient_id, :doctor_id, :date, :symptoms)
            ON DUPLICATE KEY UPDATE symptoms = :symptoms
        ";
        $stmt = $pdo->prepare($insertVisitQuery);
        $stmt->execute([
            'appointment_id'=>$appointment_id,
            'patient_id' => $appointment['patient_id'],
            'doctor_id' => $appointment['doctor_id'],
            'date' => $appointment['appointment_date'],
            'symptoms' => $symptoms
        ]);

        header("Location: appointments.php");
        exit();
    } else {
        $error = "Unable to find the appointment or invalid status.";
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Your Appointments | HealthHorizon</title>
    <link rel="icon" href="/final/PIC/favicon.ico" type="image/x-icon">
    <link href="https://fonts.googleapis.com/css2?family=Roboto:wght@400;500;700&display=swap" rel="stylesheet">
    <style>
        body {
            font-family: 'Roboto', sans-serif;
            background-color: #f7f9fc;
            color: #2c3e50;
            margin: 0;
            padding: 0;
        }
        header {
            background-color: #ffffff;
            color: #0056b3;
            padding: 10px 20px;
            display: flex;
            justify-content: space-between;
            align-items: center;
            border-bottom: 2px solid #e3e3e3;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
        }
        .header-left {
            display: flex;
            align-items: center;
        }
        .logo {
            height: 50px;
            width: auto;
        }
        h1 {
            font-size: 24px;
            margin: 0;
            padding-left: 20px;
        }
        .logout-btn {
    background-color: #0056b3;
    color: white;
    padding: 6px 12px; /* Adjusted padding for a more compact size */
    font-size: 14px; /* Slightly smaller font size */
    border: none;
    border-radius: 5px;
    cursor: pointer;
    transition: background-color 0.3s ease;
    width: auto; /* Ensure it adjusts to content size */
    display: inline-block; /* Prevent stretching to the full width */
}
.logout-btn:hover {
    background-color: #00408a;
}

        nav {
            display: flex;
            justify-content: center;
            background-color: #023e8a;
            padding: 10px 0;
        }
        nav a {
            color: #ffffff;
            text-decoration: none;
            margin: 0 15px;
            font-size: 16px;
            font-weight: 500;
            padding: 8px 12px;
            border-radius: 5px;
            transition: background-color 0.3s ease;
        }
        nav a:hover {
            background-color: #00b4d8;
        }
        .content {
            max-width: 800px;
            margin: 20px auto;
            background: white;
            padding: 20px;
            border-radius: 10px;
            box-shadow: 0 8px 16px rgba(0, 0, 0, 0.2);
        }
        table {
            width: 100%;
            border-collapse: collapse;
            margin-top: 20px;
        }
        th, td {
            border: 1px solid #ddd;
            text-align: left;
            padding: 8px;
        }
        th {
            background-color: #f4f4f4;
        }
        textarea, select, input[type="date"], button {
            margin-top: 10px;
            padding: 10px;
            width: 100%;
            box-sizing: border-box;
        }
    </style>
</head>
<body>
    <header>
        <div class="header-left">
            <img src="/PIC/WhatsApp Image 2024-12-08 at 15.12.54_61cd6b5b.jpg" alt="HealthHorizon Logo" class="logo">
            <h1>Welcome, <?= htmlspecialchars($_SESSION['name']) ?></h1>
        </div>
        <button class="logout-btn" onclick="location.href='logout.php'">Logout</button>
    </header>
    <nav>
        <a href="patient_dashboard.php">Patient Information</a>
        <a href="appointments.php" class="active">Appointments</a>
        <a href="history.php">Visit's History</a>
        <a href="edit_patient.php">Edit Info</a>
    </nav>
    <div class="content">
        <h2>Your Appointments</h2>
        <?php if (empty($appointments)): ?>
            <p>No appointments found.</p>
        <?php else: ?>
            <table>
                <tr>
                    <th>Date</th>
                    <th>Status</th>
                    <th>Doctor</th>
                    <th>Specialty</th>
                </tr>
                <?php foreach ($appointments as $appointment): ?>
                    <tr>
                        <td><?= htmlspecialchars($appointment['appointment_date']) ?></td>
                        <td><?= htmlspecialchars($appointment['status']) ?></td>
                        <td><?= htmlspecialchars($appointment['doctor_name']) ?></td>
                        <td><?= htmlspecialchars($appointment['specialty_name']) ?></td>
                    </tr>
                <?php endforeach; ?>
            </table>
        <?php endif; ?>

        <h2>Book an Appointment</h2>
        <form method="post">
            <label for="specialty">Specialty:</label>
            <select name="specialty_id" id="specialty" onchange="updateDoctors(this.value)" required>
                <option value="">Select Specialty</option>
                <?php foreach ($specialties as $specialty): ?>
                    <option value="<?= $specialty['id'] ?>"><?= htmlspecialchars($specialty['specialty_name']) ?></option>
                <?php endforeach; ?>
            </select>

            <label for="doctor">Doctor:</label>
            <select name="doctor_id" id="doctor" required>
                <option value="">Select Doctor</option>
                <?php foreach ($doctors as $doctor): ?>
                    <option class="<?= $doctor['specialty_id'] ?>" value="<?= $doctor['id'] ?>"><?= htmlspecialchars($doctor['name']) ?></option>
                <?php endforeach; ?>
            </select>

            <label for="date">Date:</label>
            <input type="date" name="appointment_date" id="date" required>
            <button type="submit" name="book_appointment">Book Appointment</button>
        </form>

        <h2>Interact with Doctor</h2>
        <form method="POST">
            <label for="appointment">Select Appointment:</label>
            <select name="appointment_id" id="appointment" required>
                <option value="">Select an Appointment</option>
                <?php foreach ($appointments as $appointment): ?>
                    <?php if ($appointment['status'] === 'Accepted'): ?>
                        <option value="<?= $appointment['appointment_id'] ?>">
                            <?= htmlspecialchars($appointment['appointment_date'] . " with " . $appointment['doctor_name']) ?>
                        </option>
                    <?php endif; ?>
                <?php endforeach; ?>
            </select>
            <label for="symptoms">Symptoms:</label>
            <textarea name="symptoms" id="symptoms" required></textarea>
            <label for="history">History:</label>
            <textarea name="history" id="history" required></textarea>
            <button type="submit" name="submit_interaction">Submit</button>
        </form>
    </div>
    <script>
        function updateDoctors(specialtyId) {
            const doctors = document.querySelectorAll('#doctor option');
            doctors.forEach(doctor => {
                doctor.style.display = doctor.className === specialtyId.toString() ? 'block' : 'none';
            });
        }
    </script>
</body>
</html>
