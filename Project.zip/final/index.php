<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>HealthHorizon</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            margin: 0;
            padding: 0;
            background-color: #f4f4f9;
        }

        /* Logo Section */
        .logo-container {
            background-color: white;
            display: flex;
            align-items: center;
            justify-content: space-between;
            padding: 20px 40px;
            margin-left: 40px;
        }

        .logo-container img {
            width: 120px;
            height: auto;
        }

        .logo-text {
            font-size: 30px;
            font-weight: bold;
            color: #003366;
            margin-left: 15px;
            text-transform: uppercase;
        }

        /* Dropdown */
        .dropdown {
            position: relative;
        }

        .dropbtn {
            background-color: #0056b3;
            color: white;
            padding: 15px 25px;
            font-size: 16px;
            border: none;
            border-radius: 8px;
            cursor: pointer;
            transition: background-color 0.3s ease;
        }

        .dropbtn:hover {
            background-color: #00408a;
        }

        .dropdown-content {
            display: none;
            position: absolute;
            background-color: #0056b3;
            min-width: 150px;
            box-shadow: 0px 8px 16px rgba(0, 0, 0, 0.2);
            z-index: 1;
            border-radius: 8px;
            overflow: hidden;
        }

        .dropdown-content a {
            color: white;
            padding: 12px;
            text-decoration: none;
            text-align: center;
            display: block;
            transition: background-color 0.3s ease;
        }

        .dropdown-content a:hover {
            background-color: #00408a;
        }

        .dropdown:hover .dropdown-content {
            display: block;
        }

        /* Navigation Bar */
        nav {
            background-color: #003366;
            color: white;
            padding: 12px 40px;
            display: flex;
            justify-content: center;
            align-items: center;
            font-weight: bold;
        }

        nav a {
            color: white;
            text-decoration: none;
            margin: 0 30px;
            font-size: 18px;
            transition: text-decoration 0.3s ease;
        }

        nav a:hover {
            text-decoration: underline;
        }

        /* Image Carousel */
        .image-container {
            margin: 0;
            padding: 0;
        }

        .carousel-image {
            width: 100%;
            height: 600px;
            object-fit: cover;
            display: block;
        }

        /* Content Section */
        section {
            padding: 40px 20px;
            text-align: center;
            background-color: #eaf1f8;
        }

        section h2 {
            color: #003366;
            font-size: 30px;
            font-family: "Georgia", serif;
            font-weight: bold;
            margin-bottom: 15px;
        }

        section p {
            color: #666;
            font-size: 18px;
            line-height: 1.6;
            max-width: 800px;
            margin: 0 auto;
        }

        /* Footer */
        footer {
            background-color: #023e8a;
            color: #fff;
            text-align: center;
            padding: 20px 0;
            font-size: 14px;
        }

        footer a {
            color: #00b4d8;
            text-decoration: none;
        }

        footer a:hover {
            text-decoration: underline;
        }
    </style>
</head>
<body>
    <!-- Logo Section -->
    <div class="logo-container">
        <!-- Logo and Text -->
        <div style="display: flex; align-items: center;">
            <img src="/PIC/WhatsApp Image 2024-12-08 at 15.12.54_61cd6b5b.jpg" alt="HealthHorizon Logo">
            <span class="logo-text">HealthHorizon</span>
        </div>

        <!-- Dropdown -->
        <div class="dropdown">
            <button class="dropbtn">Your Account</button>
            <div class="dropdown-content">
                <a href="login.php">Login</a>
                <a href="signup.php">Sign Up</a>
            </div>
        </div>
    </div>

    <!-- Navigation Bar -->
    <nav>
        <a href="#about">About Us</a>
        <a href="#services">Our Services</a>
        <a href="#contact">Get in Touch</a>
    </nav>

    <!-- Image Carousel -->
    <div class="image-container">
        <img src="/PIC/4.jpg" alt="Healthcare Excellence" class="carousel-image" id="carousel-image">
    </div>

    <!-- Content Section -->
    <section id="about">
        <h2>Welcome to HealthHorizon - Pioneering Healthcare Solutions</h2>
        <p>At HealthHorizon, we blend cutting-edge technology with compassionate care to provide personalized healthcare solutions. Our dedicated team of experts, state-of-the-art facilities, and patient-first approach ensure that your health is in safe hands. Experience the future of healthcare today.</p>
    </section>

    <section id="services">
        <h2>Our Premier Services</h2>
        <p><strong>24/7 Emergency Care:</strong> Receive immediate attention from our experienced medical staff, available around the clock for any urgent healthcare needs.<br>
        <strong>Precision Surgeries:</strong> Our skilled surgeons employ advanced techniques, including minimally invasive and robotic-assisted surgeries, ensuring faster recovery times and better outcomes.</p>
    </section>

    <section id="contact">
        <h2>Contact Us</h2>
        <p>Have a question or want to schedule an appointment? Reach out to us anytime!</p>
        <p>Email: <a href="mailto:contact@healthhorizon.com">contact@healthhorizon.com</a> | Phone: +123 456 7890</p>
    </section>

    <footer>
        <p>&copy; 2024 HealthHorizon. All Rights Reserved. | <a href="#privacy-policy">Privacy Policy</a></p>
    </footer>

    <!-- JavaScript for Image Carousel -->
    <script>
        const images = [
            "/PIC/4.jpg",
            "/PIC/3.jpg",
            "/final/final/PIC/homepagebanner1.jpg",
            "/final/final/PIC/Pic2.jpg"
        ];
        let currentImageIndex = 0;

        function changeImage() {
            const imageElement = document.getElementById("carousel-image");
            currentImageIndex = (currentImageIndex + 1) % images.length;
            imageElement.src = images[currentImageIndex];
        }

        // Change image every 5 seconds
        setInterval(changeImage, 5000);
    </script>
</body>
</html>
