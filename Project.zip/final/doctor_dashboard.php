<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Doctor Dashboard | HealthHorizon</title>
    <link href="https://fonts.googleapis.com/css2?family=Roboto:wght@400;500;700&display=swap" rel="stylesheet">
    <style>
        body {
            font-family: 'Roboto', sans-serif;
            margin: 0;
            padding: 0;
            background-color: #f7f9fc;
            color: #333;
        }
        header {
            background-color: #0056b3;
            color: white;
            padding: 20px;
            display: flex;
            align-items: center;
        }
        .header-left {
            display: flex;
            align-items: center;
            background-color: white;
            padding: 10px;
            border-radius: 10px;
            box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
            margin-right: 20px;
        }
        .logo {
            height: 50px;
            width: auto;
        }
        .header-text {
            flex-grow: 1;
            font-size: 24px;
            font-weight: bold;
            text-align: left;
            color: white;
        }
        nav {
            background-color: white;
            box-shadow: 0px 4px 8px rgba(0, 0, 0, 0.1);
            display: flex;
            justify-content: center; /* Center the buttons horizontally */
            align-items: center; /* Align the buttons vertically */
            gap: 20px; /* Add spacing between buttons */
            padding: 15px 0;
        }
        nav a {
            color: #0056b3;
            text-decoration: none;
            padding: 10px 20px;
            border: 2px solid #0056b3;
            border-radius: 25px;
            font-size: 16px;
            font-weight: bold;
            transition: all 0.3s ease;
        }
        nav a:hover {
            background-color: #0056b3;
            color: white;
        }
        .container {
            max-width: 800px;
            margin: 30px auto;
            background: white;
            padding: 30px;
            border-radius: 10px;
            box-shadow: 0px 8px 16px rgba(0, 0, 0, 0.2);
        }
        h2 {
            color: #0056b3;
            font-size: 22px;
            margin-bottom: 20px;
        }
        .info-box {
            background-color: #e9ecef;
            padding: 20px;
            border-radius: 5px;
            margin-bottom: 20px;
        }
        .info-box p {
            font-size: 18px;
            margin: 10px 0;
        }
        p {
            font-size: 16px;
            line-height: 1.6;
        }
        footer {
            background-color: #023e8a;
            color: white;
            text-align: center;
            padding: 10px 0;
            font-size: 14px;
            position: fixed;
            bottom: 0;
            width: 100%;
        }
    </style>
</head>
<body>
    <?php
    session_start();
    require 'database.php';

    // Ensure the user is logged in and is a doctor
    if (!isset($_SESSION['user_id']) || $_SESSION['role'] !== 'Doctor') {
        header("Location: login.php");
        exit();
    }

    $doctor_id = $_SESSION['user_id'];

    // Fetch the doctor's information
    $query = "SELECT name, specialty, contact_number,gender,address FROM doctors WHERE id = :doctor_id";
    $stmt = $pdo->prepare($query);
    $stmt->execute(['doctor_id' => $doctor_id]);
    $doctor = $stmt->fetch(PDO::FETCH_ASSOC);
    ?>

    <header>
        <div class="header-left">
            <img src="/PIC/WhatsApp Image 2024-12-08 at 15.12.54_61cd6b5b.jpg" alt="HealthHorizon Logo" class="logo">
        </div>
        <div class="header-text">
            Welcome, Dr. <?= htmlspecialchars($doctor['name']) ?>
        </div>
    </header>
    <nav>
        <a href="doctor_dashboard.php">Dashboard</a>
        <a href="doctors_patient.php">Manage Patients</a>
        <a href="doctors_appointments.php">Manage Appointments</a>
        <a href="edit_doctor.php">Edit Info</a>
        <a href="logout.php">Logout</a>
    </nav>
    <div class="container">
        <h2>Your Information</h2>
        <div class="info-box">
            <p><strong>Name:</strong> <?= htmlspecialchars($doctor['name']) ?></p>
            <p><strong>Gender:</strong> 
            <?php 
                if ($doctor['gender'] == 'M') {
                    echo "Male";
                } elseif ($doctor['gender'] == 'F') {
                    echo "Female";
                } else {
                    echo "Unknown"; // In case the gender is neither 'M' nor 'F'
                }
            ?>
            </p>

            <p><strong>Specialty:</strong> <?= htmlspecialchars($doctor['specialty']) ?></p>
            <p><strong>Contact Number:</strong> <?= htmlspecialchars($doctor['contact_number']) ?></p>
            <p><strong>Address:</strong> <?= htmlspecialchars($doctor['address']) ?></p>
        </div>
        <p>Navigate through the menu above to manage patients, appointments, and more.</p>
    </div>
    <footer>
        &copy; 2024 HealthHorizon. All Rights Reserved.
    </footer>
</body>
</html>
