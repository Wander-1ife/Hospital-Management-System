<?php
session_start();
require 'database.php';

if (!isset($_SESSION['user_id']) || $_SESSION['role'] !== 'Patient') {
    header("Location: login.php");
    exit();
}

$patient_id = $_SESSION['user_id'];
$stmt = $pdo->prepare("SELECT name, mrn, date_of_birth, gender, address, contact_number FROM Patients WHERE id = :patient_id");
$stmt->execute(['patient_id' => $patient_id]);
$patient = $stmt->fetch(PDO::FETCH_ASSOC);

if (!$patient) {
    echo "Patient information not found.";
    exit();
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Patient Dashboard | HealthHorizon</title>
    <link rel="icon" href="/final/PIC/favicon.ico" type="image/x-icon">
    <link href="https://fonts.googleapis.com/css2?family=Roboto:wght@400;500;700&display=swap" rel="stylesheet">
    <style>
        body {
            font-family: 'Roboto', sans-serif;
            margin: 0;
            padding: 0;
            background-color: #f7f9fc;
            color: #2c3e50;
        }
        header {
            background-color: #ffffff;
            color: #0056b3;
            padding: 10px 20px;
            display: flex;
            justify-content: space-between;
            align-items: center;
            border-bottom: 2px solid #e3e3e3;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
        }
        .header-left {
            display: flex;
            align-items: center;
        }
        .logo {
            height: 50px;
            width: auto;
        }
        h1 {
            font-size: 24px;
            margin: 0;
            padding-left: 20px;
        }
        .logout-btn {
            background-color: #0056b3;
            color: white;
            padding: 8px 16px;
            font-size: 16px;
            border: none;
            border-radius: 5px;
            cursor: pointer;
            transition: background-color 0.3s ease;
        }
        .logout-btn:hover {
            background-color: #00408a;
        }
        nav {
            display: flex;
            justify-content: center;
            background-color: #023e8a;
            padding: 10px 0;
        }
        nav a {
            color: #ffffff;
            text-decoration: none;
            margin: 0 15px;
            font-size: 16px;
            font-weight: 500;
            padding: 8px 12px;
            border-radius: 5px;
            transition: background-color 0.3s ease;
        }
        nav a:hover {
            background-color: #00b4d8;
        }
        .content {
            max-width: 800px;
            margin: 20px auto;
            background: white;
            padding: 20px;
            border-radius: 10px;
            box-shadow: 0 8px 16px rgba(0, 0, 0, 0.2);
        }
        .info p {
            font-size: 18px;
            line-height: 1.6;
            margin: 10px 0;
        }
        footer {
            background-color: #023e8a;
            color: #fff;
            text-align: center;
            padding: 15px 0;
            font-size: 14px;
        }
    </style>
</head>
<body>
    <header>
        <div class="header-left">
            <img src="/PIC/WhatsApp Image 2024-12-08 at 15.12.54_61cd6b5b.jpg" alt="HealthHorizon Logo" class="logo">
            <h1>Welcome, <?= htmlspecialchars($patient['name']) ?></h1>
        </div>
        <button class="logout-btn" onclick="location.href='logout.php'">Logout</button>
    </header>
    <nav>
        <a href="patient_dashboard.php">Patient Information</a>
        <a href="appointments.php">Appointments</a>
        <a href="history.php">Visit's History</a>
        <a href="edit_patient.php">Edit Info</a>
    </nav>
    <div class="content">
        <h2>Patient Information</h2>
        <div class="info">
            <p><strong>Name:</strong> <?= htmlspecialchars($patient['name']) ?></p>
            <p><strong>MRN:</strong> <?= htmlspecialchars($patient['mrn']) ?></p>
            <p><strong>Date of Birth:</strong> <?= date('F j, Y', strtotime($patient['date_of_birth'])) ?></p>
            <p><strong>Gender:</strong> 
            <?php 
                if ($patient['gender'] == 'M') {
                    echo "Male";
                } elseif ($patient['gender'] == 'F') {
                    echo "Female";
                } else {
                    echo "Unknown"; // In case the gender is neither 'M' nor 'F'
                }
            ?>
            </p>
            <p><strong>Address:</strong> <?= htmlspecialchars($patient['address']) ?></p>
            <p><strong>Contact:</strong> <?= htmlspecialchars($patient['contact_number']) ?></p>
        </div>
    </div>
</body>
</html>
