<?php
session_start();
require 'database.php';

if (!isset($_SESSION['user_id']) || $_SESSION['role'] !== 'Patient') {
    header("Location: login.php");
    exit();
}

$patient_id = $_SESSION['user_id'];
$stmt = $pdo->prepare("SELECT Visits.id AS visit_id, Visits.date AS visit_date, Visits.symptoms, Doctors.name AS doctor_name,Visits.diagnosis,Visits.prescription 
                      FROM Visits 
                      JOIN Doctors ON Visits.doctor_id = Doctors.id 
                      WHERE Visits.patient_id = :patient_id 
                      ORDER BY Visits.date DESC");
$stmt->execute(['patient_id' => $patient_id]);
$visits = $stmt->fetchAll(PDO::FETCH_ASSOC);
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Visit History | HealthHorizon</title>
    <link rel="icon" href="/final/PIC/favicon.ico" type="image/x-icon">
    <link href="https://fonts.googleapis.com/css2?family=Roboto:wght@400;500;700&display=swap" rel="stylesheet">
    <style>
        body {
            font-family: 'Roboto', sans-serif;
            margin: 0;
            padding: 0;
            background-color: #f7f9fc;
            color: #2c3e50;
        }
        header {
            background-color: #ffffff;
            color: #0056b3;
            padding: 10px 20px;
            display: flex;
            justify-content: space-between;
            align-items: center;
            border-bottom: 2px solid #e3e3e3;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
        }
        .header-left {
            display: flex;
            align-items: center;
        }
        .logo {
            height: 50px;
            width: auto;
            margin-right: 20px;
        }
        h1 {
            font-size: 24px;
            margin: 0;
        }
        .logout-btn {
            background-color: #0056b3;
            color: white;
            padding: 6px 12px; /* Compact padding */
            font-size: 14px; /* Consistent font size */
            border: none;
            border-radius: 5px;
            cursor: pointer;
            transition: background-color 0.3s ease;
            width: auto; /* Auto width */
            display: inline-block;
        }
        .logout-btn:hover {
            background-color: #00408a;
        }
        nav {
            display: flex;
            justify-content: center;
            background-color: #023e8a;
            padding: 10px 0;
        }
        nav a {
            color: #ffffff;
            text-decoration: none;
            margin: 0 15px;
            font-size: 16px;
            font-weight: 500;
            padding: 8px 12px;
            border-radius: 5px;
            transition: background-color 0.3s ease;
        }
        nav a:hover, nav a.active {
            background-color: #00b4d8;
        }
        .content {
            max-width: 800px;
            margin: 20px auto;
            background: white;
            padding: 20px;
            border-radius: 10px;
            box-shadow: 0 8px 16px rgba(0, 0, 0, 0.2);
        }
        table {
            width: 100%;
            border-collapse: collapse;
        }
        th, td {
            padding: 8px;
            border: 1px solid #ddd;
        }
        .btn {
            background-color: #007BFF;
            color: white;
            padding: 5px 15px;
            text-decoration: none;
            border-radius: 10px;
        }
        .btn:hover {
            background-color: #0056b3;
        }
        .modal {
            display: none;
            position: fixed;
            top: 50%;
            left: 50%;
            transform: translate(-50%, -50%);
            width: 80%;
            max-width: 700px;
            background-color: white;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.2);
            z-index: 1000;
            border-radius: 10px;
            overflow: hidden;
        }
        .modal-header, .modal-footer {
            background-color: #f1f1f1;
            padding: 10px;
            text-align: center;
        }
        .modal-body {
            padding: 20px;
        }
        .close-btn {
            float: right;
            font-size: 18px;
            font-weight: bold;
            cursor: pointer;
        }
        .overlay {
            display: none;
            position: fixed;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background: rgba(0, 0, 0, 0.5);
            z-index: 999;
        }
    </style>
</head>
<body>
    <header>
        <div class="header-left">
            <img src="/PIC/WhatsApp Image 2024-12-08 at 15.12.54_61cd6b5b.jpg" alt="HealthHorizon Logo" class="logo">
            <h1>Welcome, <?= htmlspecialchars($_SESSION['name']) ?></h1>
        </div>
        <button class="logout-btn" onclick="location.href='logout.php'">Logout</button>
    </header>
    <nav>
        <a href="patient_dashboard.php">Patient Information</a>
        <a href="appointments.php">Appointments</a>
        <a href="history.php" class="active">Visit's History</a>
        <a href="edit_patient.php">Edit Info</a>
    </nav>
    <div class="content">
        <h2>Past Visits</h2>
        <?php if (empty($visits)): ?>
            <p>No visits found.</p>
        <?php else: ?>
            <table>
                <tr>
                    <th>Date</th>
                    <th>Doctor</th>
                    <th>Symptoms</th>
                    <th>Diagnosis</th>
                    <th>Prescription</th>
                    <th>Invoice</th>
                </tr>
                <?php foreach ($visits as $visit): ?>
                    <tr>
                        <td><?= htmlspecialchars($visit['visit_date']) ?></td>
                        <td><?= htmlspecialchars($visit['doctor_name']) ?></td>
                        <td><?= htmlspecialchars($visit['symptoms']) ?></td>
                        <td><?= htmlspecialchars($visit['diagnosis']) ?></td>
                        <td><?= htmlspecialchars($visit['prescription']) ?></td>
                        <td>
                            <a href="#" class="btn view-invoice" data-visit-id="<?= $visit['visit_id'] ?>">Invoice</a>
                        </td>
                    </tr>
                <?php endforeach; ?>
            </table>
        <?php endif; ?>
    </div>

    <div class="overlay"></div>
    <div class="modal" id="invoiceModal">
        <div class="modal-header">
            <span class="close-btn">&times;</span>
            <h3>Invoice Details</h3>
        </div>
        <div class="modal-body">
            <iframe id="invoiceFrame" src="" style="width:100%; height:400px; border:none;"></iframe>
        </div>
    </div>

    <script>
        const modal = document.getElementById('invoiceModal');
        const overlay = document.querySelector('.overlay');
        const closeBtn = document.querySelector('.close-btn');
        const invoiceFrame = document.getElementById('invoiceFrame');

        document.querySelectorAll('.view-invoice').forEach(button => {
            button.addEventListener('click', event => {
                event.preventDefault();
                const visitId = button.getAttribute('data-visit-id');
                invoiceFrame.src = `generate_invoices.php?visit_id=${visitId}`;
                modal.style.display = 'block';
                overlay.style.display = 'block';
            });
        });

        closeBtn.addEventListener('click', () => {
            modal.style.display = 'none';
            overlay.style.display = 'none';
            invoiceFrame.src = '';
        });

        overlay.addEventListener('click', () => {
            modal.style.display = 'none';
            overlay.style.display = 'none';
            invoiceFrame.src = '';
        });
    </script>
</body>
</html>
