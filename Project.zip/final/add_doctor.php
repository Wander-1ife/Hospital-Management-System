<?php
session_start();
require 'database.php';

if (!isset($_SESSION['user_id']) || $_SESSION['role'] !== 'Admin') {
    header("Location: login.php");
    exit();
}

$message = '';

// Handle Add Doctor
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['add_doctor'])) {
    $name = $_POST['name'];
    $specialty = $_POST['specialty'];
    $password = bin2hex(random_bytes(4)); // Generate an 8-character password
    $username = strtolower(str_replace(' ', '', $name)) . rand(100, 999); // Generate a username

    // Hash the password
    $password_hash = password_hash($password, PASSWORD_DEFAULT);

    try {
        $stmt = $pdo->prepare("INSERT INTO Doctors (name, specialty, username, password_hash) VALUES (:name, :specialty, :username, :password_hash)");
        $stmt->execute([
            'name' => $name,
            'specialty' => $specialty,
            'username' => $username,
            'password_hash' => $password_hash
        ]);
        $message = "Doctor added successfully! Username: <strong>$username</strong>, Password: <strong>$password</strong>";
    } catch (PDOException $e) {
        $message = "Error: " . $e->getMessage();
    }
}

// Handle Delete Doctor
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['delete_id'])) {
    $delete_id = $_POST['delete_id'];
    $deleteStmt = $pdo->prepare("DELETE FROM Doctors WHERE id = :id");
    $deleteStmt->execute(['id' => $delete_id]);
    header("Location: manage_doctors.php");
    exit();
}

// Fetch all doctors
$stmt = $pdo->query("SELECT * FROM Doctors ORDER BY id ASC");
$doctors = $stmt->fetchAll(PDO::FETCH_ASSOC);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Manage Doctors</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            margin: 0;
            padding: 0;
            background-color: #f4f4f4;
        }
        .content {
            max-width: 800px;
            margin: auto;
            background: white;
            padding: 20px;
            border-radius: 8px;
            box-shadow: 0px 4px 8px rgba(0, 0, 0, 0.2);
            margin-top: 50px;
        }
        table {
            width: 100%;
            border-collapse: collapse;
            margin-top: 20px;
        }
        th, td {
            padding: 8px;
            border: 1px solid #ddd;
        }
        form input, form button {
            padding: 10px;
            margin: 5px 0;
            border-radius: 5px;
            border: 1px solid #ddd;
            width: 100%;
        }
        form button {
            background-color: #007BFF;
            color: white;
            border: none;
            cursor: pointer;
        }
        form button:hover {
            background-color: #0056b3;
        }
        .btn-remove {
            background-color: #dc3545;
        }
        .btn-remove:hover {
            background-color: #c82333;
        }
        .message {
            text-align: center;
            margin-bottom: 20px;
            color: green;
        }
        .error {
            color: red;
        }
    </style>
</head>
<body>
    <div class="content">
        <h2>Manage Doctors</h2>
        
        <!-- Message -->
        <?php if ($message): ?>
            <p class="<?= strpos($message, 'Error') === false ? 'message' : 'error' ?>">
                <?= htmlspecialchars($message) ?>
            </p>
        <?php endif; ?>

        <!-- Add Doctor Form -->
        <form method="POST">
            <h3>Add a New Doctor</h3>
            <input type="text" name="name" placeholder="Doctor's Full Name" required>
            <input type="text" name="specialty" placeholder="Specialty" required>
            <button type="submit" name="add_doctor">Add Doctor</button>
        </form>

        <!-- Doctors Table -->
        <h3>Existing Doctors</h3>
        <?php if ($doctors): ?>
            <table>
                <thead>
                    <tr>
                        <th>ID</th>
                        <th>Name</th>
                        <th>Specialty</th>
                        <th>Username</th>
                        <th>Actions</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($doctors as $doctor): ?>
                        <tr>
                            <td><?= htmlspecialchars($doctor['id']) ?></td>
                            <td><?= htmlspecialchars($doctor['name']) ?></td>
                            <td><?= htmlspecialchars($doctor['specialty']) ?></td>
                            <td><?= htmlspecialchars($doctor['username']) ?></td>
                            <td>
                                <form method="POST" style="display: inline;">
                                    <input type="hidden" name="delete_id" value="<?= $doctor['id'] ?>">
                                    <button type="submit" class="btn-remove">Remove</button>
                                </form>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        <?php else: ?>
            <p>No doctors found.</p>
        <?php endif; ?>
    </div>
</body>
</html>
