<?php
session_start();
require 'database.php';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $username = $_POST['username'];
    $password = $_POST['password'];
    $role = $_POST['role'];

    // Capture client details
    $ip_address = $_SERVER['REMOTE_ADDR'];
    $user_agent = $role;

    try {
        if ($role === 'Admin') {
            $stmt = $pdo->prepare("SELECT * FROM Admins WHERE username = ?");
        } elseif ($role === 'Doctor') {
            $stmt = $pdo->prepare("SELECT * FROM Doctors WHERE id = ?");
        } elseif ($role === 'Patient') {
            $stmt = $pdo->prepare("SELECT * FROM Patients WHERE mrn = ?");
        } else {
            throw new Exception("Invalid role selected.");
        }

        $stmt->execute([$username]);
        $user = $stmt->fetch(PDO::FETCH_ASSOC);

        if ($user && password_verify($password, $user['password_hash'])) {
            $_SESSION['user_id'] = $user['id'];
            $_SESSION['role'] = $role;
            $_SESSION['name'] = $user['name'];

            // Log the successful login
            $logStmt = $pdo->prepare("
                INSERT INTO login_logs (user_id, username, status, ip_address, user_agent)
                VALUES (:user_id, :username, 'Success', :ip_address, :user_agent)
            ");
            $logStmt->execute([
                'user_id' => $username,
                'username' => $user['name'],
                'ip_address' => $ip_address,
                'user_agent' => $role
            ]);

            // Redirect based on role
            if ($role === 'Admin') {
                header("Location: admin_dashboard.php");
            } elseif ($role === 'Doctor') {
                header("Location: doctor_dashboard.php");
            } elseif ($role === 'Patient') {
                header("Location: patient_dashboard.php");
            }
            exit();
        } else {
            // Log the failed login
            $logStmt = $pdo->prepare("
                INSERT INTO login_logs (user_id, username, status, ip_address, user_agent)
                VALUES (NULL, :username, 'Failure', :ip_address, :user_agent)
            ");
            $logStmt->execute([
                'username' => $username,
                'ip_address' => $ip_address,
                'user_agent' => $role
            ]);

            // Show a generic error message to the user
            $error = "Invalid username or password. Please try again.";
        }
    } catch (PDOException $e) {
        // Log the detailed error for internal tracking
        error_log("Database error: " . $e->getMessage());

        // Show a generic error message to the user
        $error = "An error occurred. Please try again later.";
    } catch (Exception $e) {
        // Log any general errors for internal tracking
        error_log("General error: " . $e->getMessage());

        // Show a generic error message to the user
        $error = "An error occurred. Please try again later.";
    }
}
?><!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login | HealthHorizon</title>
    <link href="https://fonts.googleapis.com/css2?family=Roboto:wght@400;500;700&display=swap" rel="stylesheet">
    <style>
        body {
            font-family: 'Roboto', sans-serif;
            margin: 0;
            padding: 0;
            background-color: #f7f9fc;
            display: flex;
            justify-content: center;
            align-items: center;
            height: 100vh;
            color: #333;
        }
        .form-container {
            background: #ffffff;
            padding: 30px 40px;
            border-radius: 10px;
            box-shadow: 0px 8px 16px rgba(0, 0, 0, 0.2);
            width: 100%;
            max-width: 400px;
            text-align: center;
        }
        h2 {
            color: #0056b3;
            margin-bottom: 20px;
            font-size: 24px;
        }
        input, select, button {
            width: 100%;
            padding: 12px;
            margin: 10px 0;
            border: 1px solid #ddd;
            border-radius: 5px;
            font-size: 16px;
        }
        button {
            background-color: #0056b3;
            color: white;
            border: none;
            cursor: pointer;
            font-size: 18px;
            transition: background-color 0.3s ease;
        }
        button:hover {
            background-color: #00408a;
        }
        .btn {
            display: inline-block;
            margin-top: 15px;
            color: #0056b3;
            text-decoration: none;
            font-size: 16px;
            font-weight: 500;
        }
        .btn:hover {
            text-decoration: underline;
        }
        .back-button {
            margin-top: 20px;
            display: inline-block;
            background-color: #023e8a;
            color: white;
            text-decoration: none;
            padding: 10px 20px;
            border-radius: 5px;
            font-size: 16px;
            transition: background-color 0.3s ease;
        }
        .back-button:hover {
            background-color: #00b4d8;
        }
    </style>
</head>
<body>
    <div class="form-container">
        <h2>Welcome Back</h2>
        <?php if (isset($error)) echo "<p style='color:red;'>$error</p>"; ?>
        <form method="POST">
            <input type="text" name="username" placeholder="Username / MRN / Doctor ID" required>
            <input type="password" name="password" placeholder="Password" required>
            <select name="role" required>
                <option value="" disabled selected>Select Role</option>
                <option value="Admin">Admin</option>
                <option value="Doctor">Doctor</option>
                <option value="Patient">Patient</option>
            </select>
            <button type="submit">Login</button>
            <a href="signup.php" class="btn">Don't have an account? Sign Up</a>
        </form>
        <a href="index.php" class="back-button">← Back to Main Page</a>
    </div>
</body>
</html>
