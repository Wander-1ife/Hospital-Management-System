<?php
session_start();
require 'database.php';

// Ensure the user is logged in and is a doctor
if (!isset($_SESSION['user_id']) || $_SESSION['role'] !== 'Doctor') {
    header("Location: login.php");
    exit();
}

$doctor_id = $_SESSION['user_id'];

// Fetch unique patient list, visit details, and appointment history for the logged-in doctor
$query = "
    SELECT 
        p.id AS patient_id, 
        p.name AS patient_name, 
        p.mrn, 
        p.contact_number, 
        v.id AS visit_id, 
        a.appointment_id, 
        v.symptoms, 
        v.diagnosis, 
        v.prescription, 
        v.date AS visit_date,
        a.history AS appointment_history
    FROM patients p
    JOIN appointments a ON p.id = a.patient_id
    JOIN visits v ON v.patient_id = p.id AND v.appointment_id = a.appointment_id
    WHERE a.doctor_id = :doctor_id
    ORDER BY v.date DESC";

$stmt = $pdo->prepare($query);
$stmt->execute(['doctor_id' => $doctor_id]);

$patients = $stmt->fetchAll(PDO::FETCH_ASSOC);
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Patient List | HealthHorizon</title>
    <link href="https://fonts.googleapis.com/css2?family=Roboto:wght@400;500;700&display=swap" rel="stylesheet">
    <style>
        body {
            font-family: 'Roboto', sans-serif;
            margin: 0;
            padding: 0;
            background-color: #f7f9fc;
            color: #333;
        }
        header {
            background-color: #0056b3;
            color: white;
            padding: 20px;
            display: flex;
            align-items: center;
        }
        .header-left {
            display: flex;
            align-items: center;
            background-color: white;
            padding: 10px;
            border-radius: 10px;
            box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
            margin-right: 20px;
        }
        .logo {
            height: 50px;
            width: auto;
        }
        h1 {
            font-size: 24px;
            margin: 0;
        }
        nav {
            background-color: white;
            box-shadow: 0px 4px 8px rgba(0, 0, 0, 0.1);
            display: flex;
            justify-content: center;
            align-items: center;
            gap: 20px;
            padding: 15px 0;
        }
        nav a {
            color: #0056b3;
            text-decoration: none;
            padding: 10px 20px;
            border: 2px solid #0056b3;
            border-radius: 25px;
            font-size: 16px;
            font-weight: bold;
            transition: all 0.3s ease;
        }
        nav a:hover {
            background-color: #0056b3;
            color: white;
        }
        .container {
            max-width: 1200px;
            margin: 30px auto;
            background: white;
            padding: 30px;
            border-radius: 10px;
            box-shadow: 0px 8px 16px rgba(0, 0, 0, 0.2);
        }
        h2 {
            color: #0056b3;
            font-size: 22px;
            margin-bottom: 20px;
        }
        table {
            width: 100%;
            border-collapse: collapse;
            margin: 20px 0;
        }
        th, td {
            padding: 10px;
            border: 1px solid #ddd;
            text-align: center;
        }
        .btn {
            background-color: #0056b3;
            color: white;
            border: none;
            padding: 10px 20px;
            border-radius: 5px;
            cursor: pointer;
            font-size: 14px;
            transition: all 0.3s ease;
        }
        .btn:hover {
            background-color: #00408a;
        }
        .message {
            margin: 10px 0;
            padding: 10px;
            color: green;
            border: 1px solid green;
            border-radius: 5px;
            background-color: #e6ffe6;
        }
    </style>
</head>
<body>
    <header>
        <div class="header-left">
            <img src="/PIC/WhatsApp Image 2024-12-08 at 15.12.54_61cd6b5b.jpg" alt="HealthHorizon Logo" class="logo">
        </div>
        <h1>Patient List</h1>
    </header>
    <nav>
        <a href="doctor_dashboard.php">Dashboard</a>
        <a href="doctors_patient.php">Manage Patients</a>
        <a href="doctors_appointments.php">Manage Appointments</a>
        <a href="edit_doctor.php">Edit Info</a>
        <a href="logout.php">Logout</a>
    </nav>
    <div class="container">
        <h2>Patient Details</h2>
        <table>
            <tr>
                <th>Patient Name</th>
                <th>MRN</th>
                <th>Contact</th>
                <th>Visit ID</th>
                <th>Visit Date</th>
                <th>Symptoms</th>
                <th>Diagnosis</th>
                <th>Prescription</th>
                <th>Appointment History</th>
                <th>Actions</th>
            </tr>

            <?php foreach ($patients as $patient): ?>
            <tr>
                <td><?php echo htmlspecialchars($patient['patient_name']); ?></td>
                <td><?php echo htmlspecialchars($patient['mrn']); ?></td>
                <td><?php echo htmlspecialchars($patient['contact_number']); ?></td>
                <td><?php echo htmlspecialchars($patient['visit_id']); ?></td>
                <td><?php echo htmlspecialchars($patient['visit_date']); ?></td>
                <td><?php echo htmlspecialchars($patient['symptoms']); ?></td>
                <td><?php echo htmlspecialchars($patient['diagnosis']); ?></td>
                <td><?php echo htmlspecialchars($patient['prescription']); ?></td>
                <td><?php echo htmlspecialchars($patient['appointment_history']); ?></td>
                <td>
                    <a href="create_invoice.php?visit_id=<?php echo htmlspecialchars($patient['visit_id']); ?>" class="btn">Invoice</a>
                </td>
            </tr>
            <?php endforeach; ?>
        </table>
    </div>
</body>
</html>