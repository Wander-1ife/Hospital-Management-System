-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Dec 09, 2024 at 04:43 AM
-- Server version: 10.4.32-MariaDB
-- PHP Version: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `hospital_system`
--

-- --------------------------------------------------------

--
-- Table structure for table `admins`
--

CREATE TABLE `admins` (
  `id` int(11) NOT NULL,
  `username` varchar(255) NOT NULL,
  `name` varchar(255) NOT NULL,
  `password_hash` varchar(255) NOT NULL,
  `role` varchar(50) DEFAULT 'Admin'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `admins`
--

INSERT INTO `admins` (`id`, `username`, `name`, `password_hash`, `role`) VALUES
(2, 'sami', 'Sami-Ur-Rehman ', '$2y$10$.jQeIpPJ69l6SpRKjfnHL.U52lHFN4mSjkRhdIKxLHcu2.cRyC9YK', 'Admin'),
(5, 'hamza', 'Hamza Yousuf', '$2y$10$D5PJiBaGtFO3NeceAiClze8kPl7c1tsellSB1gXajUpMrmn5fAXDe', 'Admin');

--
-- Triggers `admins`
--
DELIMITER $$
CREATE TRIGGER `after_admin_insert` AFTER INSERT ON `admins` FOR EACH ROW BEGIN
    INSERT INTO `admins_backup` (`id`, `username`, `name`, `password_hash`, `role`, `action`)
    VALUES (NEW.id, NEW.username, NEW.name, NEW.password_hash, NEW.role, 'insert');
END
$$
DELIMITER ;
DELIMITER $$
CREATE TRIGGER `after_admin_update` AFTER UPDATE ON `admins` FOR EACH ROW BEGIN
    INSERT INTO `admins_backup` (`id`, `username`, `name`, `password_hash`, `role`, `action`)
    VALUES (NEW.id, NEW.username, NEW.name, NEW.password_hash, NEW.role, 'update');
END
$$
DELIMITER ;

-- --------------------------------------------------------

--
-- Table structure for table `admins_backup`
--

CREATE TABLE `admins_backup` (
  `id` int(11) NOT NULL,
  `username` varchar(255) NOT NULL,
  `name` varchar(255) NOT NULL,
  `password_hash` varchar(255) NOT NULL,
  `role` varchar(50) DEFAULT 'Admin',
  `action` enum('insert','update') NOT NULL,
  `timestamp` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `admins_backup`
--

INSERT INTO `admins_backup` (`id`, `username`, `name`, `password_hash`, `role`, `action`, `timestamp`) VALUES
(5, 'hamza', 'Hamza Yousuf', '$2y$10$D5PJiBaGtFO3NeceAiClze8kPl7c1tsellSB1gXajUpMrmn5fAXDe', 'Admin', 'insert', '2024-12-08 22:57:53');

-- --------------------------------------------------------

--
-- Table structure for table `appointments`
--

CREATE TABLE `appointments` (
  `appointment_id` int(11) NOT NULL,
  `patient_id` int(11) NOT NULL,
  `doctor_id` int(11) NOT NULL,
  `appointment_date` datetime NOT NULL,
  `status` varchar(50) DEFAULT NULL,
  `history` text DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `appointments`
--

INSERT INTO `appointments` (`appointment_id`, `patient_id`, `doctor_id`, `appointment_date`, `status`, `history`) VALUES
(2, 14, 14, '2024-12-14 00:00:00', 'Accepted', 'Covid');

-- --------------------------------------------------------

--
-- Table structure for table `backup_doctors`
--

CREATE TABLE `backup_doctors` (
  `id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `specialty` varchar(100) DEFAULT NULL,
  `contact_number` varchar(15) DEFAULT NULL,
  `specialty_id` int(11) DEFAULT NULL,
  `password_hash` varchar(255) NOT NULL,
  `address` varchar(255) NOT NULL,
  `gender` enum('M','F') NOT NULL,
  `backup_timestamp` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `backup_doctors`
--

INSERT INTO `backup_doctors` (`id`, `name`, `specialty`, `contact_number`, `specialty_id`, `password_hash`, `address`, `gender`, `backup_timestamp`) VALUES
(14, 'Muneeb Aziz', 'Cardiology', '123456789', 1, '$2y$10$q0mVoEqwoUSOOvsm.1nzeOY37LrTcPifI6rUgX7IU/2.MZYF1g/zq', '', 'M', '2024-12-08 21:22:22'),
(15, 'Sohaib', 'Dermatology', '123456789', 2, '$2y$10$kURLP9B1pPPynZ3C/2pns.6xLioqIPEXAvLrR.k2YuWdOhSK.QXvO', '', 'M', '2024-12-08 21:22:44'),
(16, 'Ali', 'Neurology', '123456789', 3, '$2y$10$R2.gbWG/WwyNfa53rUvhB.O95URTBnTMN2./1PxQ8KKWsfc9xtk0S', '', 'M', '2024-12-08 21:22:58'),
(17, 'Zubair', 'Pediatrics', '123456789', 4, '$2y$10$N1OERYq.d3qQkmYBlb14Ue/S/DZMGL2oh0WSUtvolcYl.J09k11iy', '', 'M', '2024-12-08 21:23:08'),
(18, 'Hassan', 'Orthopedics', '123456789', 5, '$2y$10$4YdFnesj7FXWyoiECHFLEeQ3OZA2/O3/r/cA96HvtNNdkuiOChmDi', '', 'M', '2024-12-08 21:23:19'),
(19, 'Hassan', 'Orthopedics', '123456789', 5, '$2y$10$hwII7B1x7vNViEjQDikdtOgzVWyeosOVR69cuMAokogSVNEvOuI.y', '', 'M', '2024-12-08 21:25:26');

-- --------------------------------------------------------

--
-- Table structure for table `backup_login_logs`
--

CREATE TABLE `backup_login_logs` (
  `id` int(11) NOT NULL DEFAULT 0,
  `user_id` varchar(255) NOT NULL,
  `username` varchar(255) NOT NULL,
  `login_time` timestamp NOT NULL DEFAULT current_timestamp(),
  `status` varchar(50) DEFAULT NULL,
  `ip_address` varchar(45) DEFAULT NULL,
  `user_agent` text DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `backup_login_logs`
--

INSERT INTO `backup_login_logs` (`id`, `user_id`, `username`, `login_time`, `status`, `ip_address`, `user_agent`) VALUES
(53, 'sami', 'Sami-Ur-Rehman ', '2024-12-08 21:25:08', 'Success', '::1', 'Admin'),
(54, 'MRN1733693172', 'Ayan', '2024-12-08 21:26:30', 'Success', '::1', 'Patient'),
(55, '14', 'Muneeb Aziz', '2024-12-08 21:27:12', 'Success', '::1', 'Doctor'),
(56, 'MRN1733693172', 'Ayan', '2024-12-08 21:27:29', 'Success', '::1', 'Patient'),
(57, '14', 'Muneeb Aziz', '2024-12-08 21:27:57', 'Success', '::1', 'Doctor'),
(58, 'MRN1733693172', 'Ayan', '2024-12-08 22:04:15', 'Success', '::1', 'Patient'),
(59, '14', 'Muneeb Aziz', '2024-12-08 22:04:35', 'Success', '::1', 'Doctor'),
(60, 'MRN1733693172', 'Ayan', '2024-12-08 22:04:57', 'Success', '::1', 'Patient'),
(61, '14', 'Muneeb Aziz', '2024-12-08 22:10:41', 'Success', '::1', 'Doctor'),
(62, 'MRN1733693172', 'Ayan', '2024-12-08 22:13:37', 'Success', '::1', 'Patient'),
(63, '14', 'Muneeb Aziz', '2024-12-08 22:16:57', 'Success', '::1', 'Doctor'),
(64, 'MRN1733696340', 'Sameera', '2024-12-08 22:19:15', 'Success', '::1', 'Patient'),
(65, 'sami', 'Sami-Ur-Rehman ', '2024-12-08 22:27:56', 'Success', '::1', 'Admin'),
(66, 'sami', 'Sami-Ur-Rehman ', '2024-12-08 22:34:05', 'Success', '::1', 'Admin'),
(67, 'sami', 'Sami-Ur-Rehman ', '2024-12-08 22:35:03', 'Success', '::1', 'Admin'),
(68, 'sami', 'Sami-Ur-Rehman ', '2024-12-08 22:35:57', 'Success', '::1', 'Admin'),
(69, 'sami', 'Sami-Ur-Rehman ', '2024-12-08 22:40:49', 'Success', '::1', 'Admin'),
(70, 'sami', 'Sami-Ur-Rehman ', '2024-12-08 22:43:07', 'Success', '::1', 'Admin'),
(71, 'hamza', 'Hamza Yousuf', '2024-12-08 22:43:38', 'Success', '::1', 'Admin'),
(72, 'sami', 'Sami-Ur-Rehman ', '2024-12-08 22:48:22', 'Success', '::1', 'Admin'),
(73, 'sami', 'Sami-Ur-Rehman ', '2024-12-08 22:48:46', 'Success', '::1', 'Admin'),
(74, 'sami', 'Sami-Ur-Rehman ', '2024-12-08 22:50:29', 'Success', '::1', 'Admin'),
(75, 'sami', 'Sami-Ur-Rehman ', '2024-12-08 22:57:42', 'Success', '::1', 'Admin'),
(76, 'hamza', 'Hamza Yousuf', '2024-12-08 22:58:07', 'Success', '::1', 'Admin'),
(77, 'sami', 'Sami-Ur-Rehman ', '2024-12-08 23:29:44', 'Success', '::1', 'Admin');

-- --------------------------------------------------------

--
-- Table structure for table `backup_patient`
--

CREATE TABLE `backup_patient` (
  `id` int(11) NOT NULL DEFAULT 0,
  `mrn` varchar(20) NOT NULL,
  `name` varchar(100) NOT NULL,
  `date_of_birth` date NOT NULL,
  `gender` enum('M','F') NOT NULL,
  `address` varchar(255) NOT NULL,
  `contact_number` varchar(15) NOT NULL,
  `emergency_contact` varchar(15) DEFAULT NULL,
  `password_hash` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `backup_patient`
--

INSERT INTO `backup_patient` (`id`, `mrn`, `name`, `date_of_birth`, `gender`, `address`, `contact_number`, `emergency_contact`, `password_hash`) VALUES
(14, 'MRN1733693172', 'Ayan', '2024-12-10', 'M', 'gulshan', '123456789', '236572698', '$2y$10$lzdUtRxHrW31uZ9Q0evIv./fsoKgQ4J1xxBNA5FIgWLTPTN8lLFOe'),
(15, 'MRN1733696340', 'Sameera', '2024-12-12', 'F', 'fast', '123456789', '987654321', '$2y$10$acWzDOi4VlKuum/7GHiEteVJV7KiQVTOIjJIUdGlFabKjJ8VzY3ZC');

-- --------------------------------------------------------

--
-- Table structure for table `doctors`
--

CREATE TABLE `doctors` (
  `id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `specialty` varchar(100) DEFAULT NULL,
  `contact_number` varchar(15) DEFAULT NULL,
  `specialty_id` int(11) DEFAULT NULL,
  `password_hash` varchar(255) NOT NULL,
  `address` varchar(255) NOT NULL,
  `gender` enum('M','F') NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `doctors`
--

INSERT INTO `doctors` (`id`, `name`, `specialty`, `contact_number`, `specialty_id`, `password_hash`, `address`, `gender`) VALUES
(14, 'Muneeb Aziz', 'Cardiology', '123456789', 1, '$2y$10$q0mVoEqwoUSOOvsm.1nzeOY37LrTcPifI6rUgX7IU/2.MZYF1g/zq', '', 'M'),
(15, 'Sohaib', 'Dermatology', '123456789', 2, '$2y$10$kURLP9B1pPPynZ3C/2pns.6xLioqIPEXAvLrR.k2YuWdOhSK.QXvO', '', 'M'),
(16, 'Ali', 'Neurology', '123456789', 3, '$2y$10$R2.gbWG/WwyNfa53rUvhB.O95URTBnTMN2./1PxQ8KKWsfc9xtk0S', '', 'M'),
(17, 'Zubair', 'Pediatrics', '123456789', 4, '$2y$10$N1OERYq.d3qQkmYBlb14Ue/S/DZMGL2oh0WSUtvolcYl.J09k11iy', '', 'M'),
(19, 'Hassan', 'Orthopedics', '123456789', 5, '$2y$10$hwII7B1x7vNViEjQDikdtOgzVWyeosOVR69cuMAokogSVNEvOuI.y', '', 'M');

--
-- Triggers `doctors`
--
DELIMITER $$
CREATE TRIGGER `backup_doctors_insert` AFTER INSERT ON `doctors` FOR EACH ROW BEGIN
    INSERT INTO backup_doctors (id, name, specialty, contact_number, specialty_id, password_hash, address, gender, backup_timestamp)
    VALUES (NEW.id, NEW.name, NEW.specialty, NEW.contact_number, NEW.specialty_id, NEW.password_hash, NEW.address, NEW.gender, CURRENT_TIMESTAMP);
END
$$
DELIMITER ;
DELIMITER $$
CREATE TRIGGER `backup_doctors_update` AFTER UPDATE ON `doctors` FOR EACH ROW BEGIN
    INSERT INTO backup_doctors (id, name, specialty, contact_number, specialty_id, password_hash, address, gender, backup_timestamp)
    VALUES (NEW.id, NEW.name, NEW.specialty, NEW.contact_number, NEW.specialty_id, NEW.password_hash, NEW.address, NEW.gender, CURRENT_TIMESTAMP);
END
$$
DELIMITER ;

-- --------------------------------------------------------

--
-- Table structure for table `invoices`
--

CREATE TABLE `invoices` (
  `id` int(11) NOT NULL,
  `visit_id` int(11) NOT NULL,
  `doctor_fee` decimal(10,2) NOT NULL,
  `hospital_charges` decimal(10,2) NOT NULL,
  `total` decimal(10,2) GENERATED ALWAYS AS (`doctor_fee` + `hospital_charges`) STORED
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `invoices`
--

INSERT INTO `invoices` (`id`, `visit_id`, `doctor_fee`, `hospital_charges`) VALUES
(9, 36, 100.00, 200.00);

--
-- Triggers `invoices`
--
DELIMITER $$
CREATE TRIGGER `check_invoice_amount` BEFORE INSERT ON `invoices` FOR EACH ROW BEGIN
    -- Set maximum allowed invoice amount (e.g., 1000)
    DECLARE max_invoice_amount DECIMAL(10,2) DEFAULT 1000.00;

    -- Check if the total amount exceeds the maximum allowed value
    IF NEW.total > max_invoice_amount THEN
        SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'Invoice total exceeds the maximum allowed amount (Rs.1000)';
    END IF;
END
$$
DELIMITER ;

-- --------------------------------------------------------

--
-- Table structure for table `login_logs`
--

CREATE TABLE `login_logs` (
  `id` int(11) NOT NULL,
  `user_id` varchar(255) NOT NULL,
  `username` varchar(255) NOT NULL,
  `login_time` timestamp NOT NULL DEFAULT current_timestamp(),
  `status` varchar(50) DEFAULT NULL,
  `ip_address` varchar(45) DEFAULT NULL,
  `user_agent` text DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `login_logs`
--

INSERT INTO `login_logs` (`id`, `user_id`, `username`, `login_time`, `status`, `ip_address`, `user_agent`) VALUES
(53, 'sami', 'Sami-Ur-Rehman ', '2024-12-08 21:25:08', 'Success', '::1', 'Admin'),
(54, 'MRN1733693172', 'Ayan', '2024-12-08 21:26:30', 'Success', '::1', 'Patient'),
(55, '14', 'Muneeb Aziz', '2024-12-08 21:27:12', 'Success', '::1', 'Doctor'),
(56, 'MRN1733693172', 'Ayan', '2024-12-08 21:27:29', 'Success', '::1', 'Patient'),
(57, '14', 'Muneeb Aziz', '2024-12-08 21:27:57', 'Success', '::1', 'Doctor'),
(58, 'MRN1733693172', 'Ayan', '2024-12-08 22:04:15', 'Success', '::1', 'Patient'),
(59, '14', 'Muneeb Aziz', '2024-12-08 22:04:35', 'Success', '::1', 'Doctor'),
(60, 'MRN1733693172', 'Ayan', '2024-12-08 22:04:57', 'Success', '::1', 'Patient'),
(61, '14', 'Muneeb Aziz', '2024-12-08 22:10:41', 'Success', '::1', 'Doctor'),
(62, 'MRN1733693172', 'Ayan', '2024-12-08 22:13:37', 'Success', '::1', 'Patient'),
(63, '14', 'Muneeb Aziz', '2024-12-08 22:16:57', 'Success', '::1', 'Doctor'),
(64, 'MRN1733696340', 'Sameera', '2024-12-08 22:19:15', 'Success', '::1', 'Patient'),
(75, 'sami', 'Sami-Ur-Rehman ', '2024-12-08 22:57:42', 'Success', '::1', 'Admin'),
(76, 'hamza', 'Hamza Yousuf', '2024-12-08 22:58:07', 'Success', '::1', 'Admin'),
(77, 'sami', 'Sami-Ur-Rehman ', '2024-12-08 23:29:44', 'Success', '::1', 'Admin');

--
-- Triggers `login_logs`
--
DELIMITER $$
CREATE TRIGGER `backup_login_logs` AFTER INSERT ON `login_logs` FOR EACH ROW BEGIN
    -- Insert the new record into the backup table
    INSERT INTO `backup_login_logs` (`id`, `user_id`, `username`, `login_time`, `status`, `ip_address`, `user_agent`)
    VALUES (NEW.id, NEW.user_id, NEW.username, NEW.login_time, NEW.status, NEW.ip_address, NEW.user_agent);
END
$$
DELIMITER ;
DELIMITER $$
CREATE TRIGGER `backup_login_logs_update` AFTER UPDATE ON `login_logs` FOR EACH ROW BEGIN
    INSERT INTO backup_login_logs (user_id, username, login_time, status, ip_address, user_agent)
    VALUES (NEW.user_id, NEW.username, NEW.login_time, NEW.status, NEW.ip_address, NEW.user_agent);
END
$$
DELIMITER ;

-- --------------------------------------------------------

--
-- Table structure for table `patients`
--

CREATE TABLE `patients` (
  `id` int(11) NOT NULL,
  `mrn` varchar(20) NOT NULL,
  `name` varchar(100) NOT NULL,
  `date_of_birth` date NOT NULL,
  `gender` enum('M','F') NOT NULL,
  `address` varchar(255) NOT NULL,
  `contact_number` varchar(15) NOT NULL,
  `emergency_contact` varchar(15) DEFAULT NULL,
  `password_hash` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `patients`
--

INSERT INTO `patients` (`id`, `mrn`, `name`, `date_of_birth`, `gender`, `address`, `contact_number`, `emergency_contact`, `password_hash`) VALUES
(14, 'MRN1733693172', 'Ayan', '2024-12-10', 'M', 'gulshan', '123456789', '236572698', '$2y$10$lzdUtRxHrW31uZ9Q0evIv./fsoKgQ4J1xxBNA5FIgWLTPTN8lLFOe'),
(15, 'MRN1733696340', 'Sameera', '2024-12-12', 'F', 'fast', '123456789', '987654321', '$2y$10$acWzDOi4VlKuum/7GHiEteVJV7KiQVTOIjJIUdGlFabKjJ8VzY3ZC');

--
-- Triggers `patients`
--
DELIMITER $$
CREATE TRIGGER `backup_patient` AFTER INSERT ON `patients` FOR EACH ROW BEGIN
    -- Insert the new record into the backup table
    INSERT INTO `backup_patient` (`id`, `mrn`, `name`, `date_of_birth`, `gender`, `address`, `contact_number`, `emergency_contact`, `password_hash`)
    VALUES (NEW.id, NEW.mrn, NEW.name, NEW.date_of_birth, NEW.gender, NEW.address, NEW.contact_number, NEW.emergency_contact, NEW.password_hash);
END
$$
DELIMITER ;
DELIMITER $$
CREATE TRIGGER `backup_patient_update` AFTER UPDATE ON `patients` FOR EACH ROW BEGIN
    INSERT INTO backup_patient (id, mrn, name, date_of_birth, gender, address, contact_number, emergency_contact, password_hash)
    VALUES (NEW.id, NEW.mrn, NEW.name, NEW.date_of_birth, NEW.gender, NEW.address, NEW.contact_number, NEW.emergency_contact, NEW.password_hash);
END
$$
DELIMITER ;

-- --------------------------------------------------------

--
-- Table structure for table `specialties`
--

CREATE TABLE `specialties` (
  `id` int(11) NOT NULL,
  `specialty_name` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `specialties`
--

INSERT INTO `specialties` (`id`, `specialty_name`) VALUES
(1, 'Cardiology'),
(2, 'Dermatology'),
(3, 'Neurology'),
(4, 'Pediatrics'),
(5, 'Orthopedics');

-- --------------------------------------------------------

--
-- Table structure for table `visits`
--

CREATE TABLE `visits` (
  `id` int(11) NOT NULL,
  `appointment_id` int(11) NOT NULL,
  `patient_id` int(11) NOT NULL,
  `doctor_id` int(11) NOT NULL,
  `date` date NOT NULL,
  `symptoms` text DEFAULT NULL,
  `diagnosis` text DEFAULT NULL,
  `prescription` text DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `visits`
--

INSERT INTO `visits` (`id`, `appointment_id`, `patient_id`, `doctor_id`, `date`, `symptoms`, `diagnosis`, `prescription`) VALUES
(36, 2, 14, 14, '2024-12-14', 'Fever', 'Possible Covid', 'Quarantine ');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `admins`
--
ALTER TABLE `admins`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `username` (`username`);

--
-- Indexes for table `admins_backup`
--
ALTER TABLE `admins_backup`
  ADD PRIMARY KEY (`id`,`timestamp`);

--
-- Indexes for table `appointments`
--
ALTER TABLE `appointments`
  ADD PRIMARY KEY (`appointment_id`),
  ADD KEY `patient_id` (`patient_id`),
  ADD KEY `doctor_id` (`doctor_id`);

--
-- Indexes for table `doctors`
--
ALTER TABLE `doctors`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `invoices`
--
ALTER TABLE `invoices`
  ADD PRIMARY KEY (`id`),
  ADD KEY `visit_id` (`visit_id`);

--
-- Indexes for table `login_logs`
--
ALTER TABLE `login_logs`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `patients`
--
ALTER TABLE `patients`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `mrn` (`mrn`);

--
-- Indexes for table `specialties`
--
ALTER TABLE `specialties`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `visits`
--
ALTER TABLE `visits`
  ADD PRIMARY KEY (`id`),
  ADD KEY `patient_id` (`patient_id`),
  ADD KEY `appointment_id` (`appointment_id`),
  ADD KEY `doctor_id` (`doctor_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `admins`
--
ALTER TABLE `admins`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `appointments`
--
ALTER TABLE `appointments`
  MODIFY `appointment_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `doctors`
--
ALTER TABLE `doctors`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=20;

--
-- AUTO_INCREMENT for table `invoices`
--
ALTER TABLE `invoices`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;

--
-- AUTO_INCREMENT for table `login_logs`
--
ALTER TABLE `login_logs`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=78;

--
-- AUTO_INCREMENT for table `patients`
--
ALTER TABLE `patients`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=16;

--
-- AUTO_INCREMENT for table `specialties`
--
ALTER TABLE `specialties`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;

--
-- AUTO_INCREMENT for table `visits`
--
ALTER TABLE `visits`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=38;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `appointments`
--
ALTER TABLE `appointments`
  ADD CONSTRAINT `appointments_ibfk_1` FOREIGN KEY (`patient_id`) REFERENCES `patients` (`id`),
  ADD CONSTRAINT `appointments_ibfk_2` FOREIGN KEY (`doctor_id`) REFERENCES `doctors` (`id`);

--
-- Constraints for table `invoices`
--
ALTER TABLE `invoices`
  ADD CONSTRAINT `invoices_ibfk_1` FOREIGN KEY (`visit_id`) REFERENCES `visits` (`id`);

--
-- Constraints for table `visits`
--
ALTER TABLE `visits`
  ADD CONSTRAINT `visits_ibfk_1` FOREIGN KEY (`patient_id`) REFERENCES `patients` (`id`),
  ADD CONSTRAINT `visits_ibfk_2` FOREIGN KEY (`doctor_id`) REFERENCES `doctors` (`id`),
  ADD CONSTRAINT `visits_ibfk_3` FOREIGN KEY (`appointment_id`) REFERENCES `appointments` (`appointment_id`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
