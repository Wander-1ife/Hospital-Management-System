<?php 
session_start();
require 'database.php';

if (!isset($_SESSION['user_id']) || $_SESSION['role'] !== 'Admin') {
    header("Location: login.php");
    exit();
}

// Handle Add Doctor Form Submission
$message = '';
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['add_doctor'])) {
    $name = $_POST['name'];
    $specialty_id = $_POST['specialty_id'];
    $contact_info = $_POST['contact_info'];
    $password = $_POST['password'];

    // Get the specialty name based on the selected specialty_id
    $stmt = $pdo->prepare("SELECT specialty_name FROM Specialties WHERE id = :specialty_id");
    $stmt->execute([':specialty_id' => $specialty_id]);
    $specialty_row = $stmt->fetch(PDO::FETCH_ASSOC);
    $specialty_name = $specialty_row ? $specialty_row['specialty_name'] : '';

    // Validate form data
    if (!$name || !$specialty_id || !$contact_info || !$password || !$specialty_name) {
        $message = "All fields are required!";
    } else {
        // Generate a hashed password
        $password_hash = password_hash($password, PASSWORD_DEFAULT);

        // Add the doctor to the Doctors table with the specialty name
        $query = "INSERT INTO Doctors (name, specialty, contact_number, specialty_id, password_hash) 
                  VALUES (:name, :specialty, :contact_number, :specialty_id, :password_hash)";
        $stmt = $pdo->prepare($query);
        $stmt->execute([
            ':name' => $name,
            ':specialty' => $specialty_name,
            ':contact_number' => $contact_info,
            ':specialty_id' => $specialty_id,
            ':password_hash' => $password_hash
        ]);

        $message = "Doctor added successfully!";
    }
}

// Handle Doctor Deletion
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['delete_doctor'])) {
    $doctor_id = $_POST['doctor_id'];
    $stmt = $pdo->prepare("DELETE FROM Doctors WHERE id = :id");
    $stmt->execute([':id' => $doctor_id]);
    $message = "Doctor deleted successfully!";
}

// Fetch doctors from the database
$stmt = $pdo->query("SELECT d.id, d.name, d.specialty, d.contact_number, s.specialty_name 
                     FROM Doctors d 
                     LEFT JOIN Specialties s ON d.specialty_id = s.id");
$doctors = $stmt->fetchAll(PDO::FETCH_ASSOC);

// Fetch specialties for the dropdown
$specialties = $pdo->query("SELECT id, specialty_name FROM Specialties")->fetchAll(PDO::FETCH_ASSOC);
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Manage Doctors | HealthHorizon</title>
    <link href="https://fonts.googleapis.com/css2?family=Roboto:wght@400;500;700&display=swap" rel="stylesheet">
    <style>
        body {
            font-family: 'Roboto', sans-serif;
            margin: 0;
            padding: 0;
            background-color: #f7f9fc;
            color: #333;
        }
        header {
            background-color: #0056b3;
            color: white;
            padding: 20px;
            display: flex;
            align-items: center;
        }
        .header-left {
            display: flex;
            align-items: center;
            margin-right: 20px;
        }
        .logo-container {
            display: flex;
            align-items: center;
            justify-content: center;
            padding: 10px;
            border: 2px solid #ffffff;
            border-radius: 10px;
            background-color: white;
            box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
            margin-right: 15px;
        }
        .logo {
            height: 50px;
            width: auto;
        }
        .header-text {
            font-size: 24px;
            font-weight: bold;
            color: white;
        }
        nav {
            background-color: white;
            box-shadow: 0px 4px 8px rgba(0, 0, 0, 0.1);
            display: flex;
            justify-content: center;
            align-items: center;
            gap: 20px;
            padding: 15px 0;
        }
        nav a {
            color: #0056b3;
            text-decoration: none;
            padding: 10px 20px;
            border: 2px solid #0056b3;
            border-radius: 25px;
            font-size: 16px;
            font-weight: bold;
            transition: all 0.3s ease;
        }
        nav a:hover, nav a.active {
            background-color: #0056b3;
            color: white;
        }
        .container {
            max-width: 900px;
            margin: 30px auto;
            background: white;
            padding: 30px;
            border-radius: 10px;
            box-shadow: 0px 8px 16px rgba(0, 0, 0, 0.2);
        }
        h2 {
            color: #0056b3;
            margin-bottom: 20px;
        }
        .form-group {
            margin-bottom: 15px;
        }
        label {
            display: block;
            margin-bottom: 5px;
            font-weight: bold;
        }
        input, select, button {
            width: 100%;
            padding: 10px;
            margin: 5px 0;
            border: 1px solid #ddd;
            border-radius: 5px;
            font-size: 16px;
        }
        button {
            background-color: #0056b3;
            color: white;
            font-weight: bold;
            cursor: pointer;
            transition: all 0.3s ease;
        }
        button:hover {
            background-color: #00408a;
        }
        .message {
            font-size: 16px;
            color: green;
            margin: 10px 0;
        }
        table {
            width: 100%;
            border-collapse: collapse;
            margin-top: 20px;
        }
        th, td {
            padding: 10px;
            border: 1px solid #ddd;
            text-align: left;
        }
        th {
            background-color: #e9ecef;
            color: #0056b3;
        }
        .delete-button {
            background-color: #dc3545;
            color: white;
            border: none;
            padding: 8px 12px;
            border-radius: 5px;
            cursor: pointer;
            font-size: 14px;
        }
        .delete-button:hover {
            background-color: #bd2130;
        }
        footer {
            background-color: #023e8a;
            color: white;
            text-align: center;
            padding: 10px 0;
            margin-top: 20px;
            font-size: 14px;
        }
    </style>
</head>
<body>
<header>
    <div class="header-left">
        <div class="logo-container">
            <img src="/PIC/WhatsApp Image 2024-12-08 at 15.12.54_61cd6b5b.jpg" alt="HealthHorizon Logo" class="logo">
        </div>
        <div class="header-text">Manage Doctors</div>
    </div>
</header>
 <nav>
 <a href="admin_dashboard.php">Dashboard</a>
        <a href="manage_doctors.php">Manage Doctors</a>
        <a href="manage_patients.php">Manage Patients</a>
        <a href="manage_appointments.php">Manage Appointments</a>
        <a href="logs.php">Logs</a>
    </nav>
<div class="container">
    <h2>Add Doctor</h2>
    <?php if ($message): ?>
        <p class="message"><?= htmlspecialchars($message) ?></p>
    <?php endif; ?>
    <form method="POST">
        <div class="form-group">
            <label for="name">Doctor Name:</label>
            <input type="text" id="name" name="name" required>
        </div>
        <div class="form-group">
            <label for="specialty_id">Specialty:</label>
            <select id="specialty_id" name="specialty_id" required>
                <option value="" disabled selected>Select Specialty</option>
                <?php foreach ($specialties as $specialty): ?>
                    <option value="<?= $specialty['id'] ?>"><?= htmlspecialchars($specialty['specialty_name']) ?></option>
                <?php endforeach; ?>
            </select>
        </div>
        <div class="form-group">
            <label for="contact_info">Contact Number:</label>
            <input type="text" id="contact_info" name="contact_info" required>
        </div>
        <div class="form-group">
            <label for="password">Password:</label>
            <input type="password" id="password" name="password" required>
        </div>
        <button type="submit" name="add_doctor">Add Doctor</button>
    </form>
    <h2>Existing Doctors</h2>
    <table>
        <tr>
            <th>ID</th>
            <th>Name</th>
            <th>Specialty</th>
            <th>Contact</th>
            <th>Actions</th>
        </tr>
        <?php foreach ($doctors as $doctor): ?>
            <tr>
                <td><?= htmlspecialchars($doctor['id']) ?></td>
                <td><?= htmlspecialchars($doctor['name']) ?></td>
                <td><?= htmlspecialchars($doctor['specialty']) ?></td>
                <td><?= htmlspecialchars($doctor['contact_number']) ?></td>
                <td>
                    <form method="POST" style="display:inline;">
                        <input type="hidden" name="doctor_id" value="<?= $doctor['id'] ?>">
                        <button type="submit" name="delete_doctor" class="delete-button">Delete</button>
                    </form>
                </td>
            </tr>
        <?php endforeach; ?>
    </table>
</div>
<footer>
    &copy; 2024 HealthHorizon. All Rights Reserved.
</footer>
</body>
</html>
