<?php
session_start();
require 'database.php';  // Database connection

// Ensure patient is logged in
if (!isset($_SESSION['user_id']) || $_SESSION['role'] !== 'Patient') {
    header("Location: login.php");
    exit();
}

$message = '';
$patient_id = $_SESSION['user_id'];

// Fetch patient details
$stmt = $pdo->prepare("SELECT name, contact_number, address, emergency_contact, password_hash FROM patients WHERE id = :patient_id");
$stmt->execute(['patient_id' => $patient_id]);
$patient = $stmt->fetch(PDO::FETCH_ASSOC);

// Handle form submission to update patient info
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $name = $_POST['name'];
    $contact_number = $_POST['contact_number'];
    $address = $_POST['address'];
    $emergency_contact = $_POST['emergency_contact'];
    $new_password = $_POST['new_password'];

    try {
        // If password is being updated, hash and update it
        if (!empty($new_password)) {
            // Hash the new password
            $hashed_password = password_hash($new_password, PASSWORD_BCRYPT);

            // Update the password hash and other details
            $updateQuery = "UPDATE patients SET name = :name, contact_number = :contact_number, address = :address, emergency_contact = :emergency_contact, password_hash = :password_hash WHERE id = :patient_id";
            $params = [
                'name' => $name, 
                'contact_number' => $contact_number, 
                'address' => $address, 
                'emergency_contact' => $emergency_contact, 
                'password_hash' => $hashed_password, 
                'patient_id' => $patient_id
            ];
            $stmt = $pdo->prepare($updateQuery);
            $stmt->execute($params);

            $message = "Your profile has been updated successfully!";
        } else {
            // If no password change, just update other fields
            $updateQuery = "UPDATE patients SET name = :name, contact_number = :contact_number, address = :address, emergency_contact = :emergency_contact WHERE id = :patient_id";
            $params = ['name' => $name, 'contact_number' => $contact_number, 'address' => $address, 'emergency_contact' => $emergency_contact, 'patient_id' => $patient_id];
            $stmt = $pdo->prepare($updateQuery);
            $stmt->execute($params);

            $message = "Your profile has been updated successfully!";
        }
    } catch (PDOException $e) {
        $message = "Error: " . $e->getMessage();
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Update Profile</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            margin: 0;
            padding: 0;
            background-color: #f4f4f4;
            display: flex;
            justify-content: center;
            align-items: center;
            height: 100vh;
        }
        .form-container {
            background: white;
            padding: 20px 30px;
            border-radius: 10px;
            box-shadow: 0px 4px 8px rgba(0, 0, 0, 0.2);
            width: 100%;
            max-width: 400px;
        }
        h2 {
            color: #007BFF;
            text-align: center;
        }
        label {
            font-size: 16px;
            margin-top: 10px;
            display: block;
            color: #333;
        }
        input, button {
            width: calc(100% - 20px);
            padding: 10px;
            margin: 10px 0;
            border-radius: 5px;
            border: 1px solid #ddd;
            font-size: 16px;
        }
        button {
            background-color: #007BFF;
            color: white;
            border: none;
            cursor: pointer;
        }
        button:hover {
            background-color: #0056b3;
        }
        .back-btn {
            background-color: #6c757d;
        }
        .back-btn:hover {
            background-color: #5a6268;
        }
        .message {
            text-align: center;
            margin-top: 10px;
            color: green;
        }
        .error {
            color: red;
        }
    </style>
</head>
<body>
    <div class="form-container">
        <h2>Update Your Profile</h2>
        <?php if ($message): ?>
            <p class="<?= strpos($message, 'Error') === false ? 'message' : 'error' ?>">
                <?= htmlspecialchars($message) ?>
            </p>
        <?php endif; ?>
        <form method="POST">
            <label for="name">Full Name</label>
            <input type="text" name="name" id="name" value="<?= htmlspecialchars($patient['name']) ?>" required>

            <label for="contact_number">Contact Number</label>
            <input type="text" name="contact_number" id="contact_number" value="<?= htmlspecialchars($patient['contact_number']) ?>" required>

            <label for="address">Address</label>
            <input type="text" name="address" id="address" value="<?= htmlspecialchars($patient['address']) ?>" required>

            <label for="emergency_contact">Emergency Contact</label>
            <input type="text" name="emergency_contact" id="emergency_contact" value="<?= htmlspecialchars($patient['emergency_contact']) ?>">

            <label for="new_password">New Password (Leave empty to keep current password)</label>
            <input type="password" name="new_password" id="new_password" placeholder="Enter new password">

            <button type="submit">Update</button>
        </form>
        <a href="patient_dashboard.php">
            <button class="back-btn">Go Back</button>
        </a>
    </div>
</body>
</html>
